import { Injectable } from '@angular/core';
import { HttpContextToken, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, finalize } from 'rxjs';
import { LoadingService } from './loading.service';

/** Set to true on a request that must NOT show the global bar (polling, typeahead). */
export const SKIP_GLOBAL_LOADER = new HttpContextToken<boolean>(() => false);

@Injectable()
export class LoadingInterceptor implements HttpInterceptor {
  constructor(private loading: LoadingService) {}

  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    if (req.context.get(SKIP_GLOBAL_LOADER)) return next.handle(req);
    this.loading.start();
    return next.handle(req).pipe(finalize(() => this.loading.stop()));
  }
}
