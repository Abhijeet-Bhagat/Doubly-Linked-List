import { Injectable, computed, signal } from '@angular/core';

/**
 * Counts in-flight work (HTTP calls + route changes).
 * The top progress bar is visible while count > 0, with a short delay
 * so fast calls (<150ms) never flash a bar.
 */
@Injectable({ providedIn: 'root' })
export class LoadingService {
  private readonly count = signal(0);
  readonly busy = computed(() => this.count() > 0);

  start(): void { this.count.update((n) => n + 1); }
  stop(): void { this.count.update((n) => Math.max(0, n - 1)); }

  /** Wrap any promise so it shows the global bar. */
  async track<T>(work: Promise<T>): Promise<T> {
    this.start();
    try { return await work; } finally { this.stop(); }
  }
}
