import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { NgFor, NgIf, NgSwitch, NgSwitchCase } from '@angular/common';

export type SkeletonVariant = 'list' | 'table' | 'detail' | 'tree' | 'timeline' | 'cells' | 'facts';

/**
 * Local loader: grey shimmering placeholders shaped like the content that is coming.
 * Use INSIDE the panel that is loading, in place of its rows. Never as a full-page overlay.
 *
 *   <nx-skeleton variant="table" [rows]="8" [cols]="5" />
 *   <nx-skeleton variant="list" [rows]="5" />
 */
@Component({
  selector: 'nx-skeleton',
  standalone: true,
  imports: [NgFor, NgIf, NgSwitch, NgSwitchCase],
  changeDetection: ChangeDetectionStrategy.OnPush,
  styleUrls: ['./loading.scss'],
  host: { role: 'status', 'aria-live': 'polite', '[attr.aria-label]': 'label', class: 'nx-sk' },
  template: `
    <ng-container [ngSwitch]="variant">

      <!-- List rows: title + meta (Worklist, Compare, Sandboxes, Home lists) -->
      <ng-container *ngSwitchCase="'list'">
        <div class="nx-sk__list-row" *ngFor="let r of arr(rows); let i = index">
          <span class="nx-sk__line" [style.width.%]="w(i, 55, 80)" style="height:14px"></span>
          <span class="nx-sk__line" [style.width.%]="w(i + 3, 35, 60)" style="height:11px"></span>
        </div>
      </ng-container>

      <!-- Table: header + rows x cols (Queries results, Versions, diffs) -->
      <ng-container *ngSwitchCase="'table'">
        <div class="nx-sk__table-head" [style.grid-template-columns]="grid()">
          <span class="nx-sk__line" *ngFor="let c of arr(cols)" style="height:10px; width:60%"></span>
        </div>
        <div class="nx-sk__table-row" *ngFor="let r of arr(rows); let i = index" [style.grid-template-columns]="grid()">
          <span class="nx-sk__line" *ngFor="let c of arr(cols); let j = index" [style.width.%]="w(i + j, 45, 90)" style="height:12px"></span>
        </div>
      </ng-container>

      <!-- Detail: tag, big title, facts grid, paragraph (right side of master–detail) -->
      <ng-container *ngSwitchCase="'detail'">
        <div class="nx-sk__detail">
          <span class="nx-sk__line" style="width:120px; height:18px"></span>
          <span class="nx-sk__line" style="width:55%; height:28px"></span>
          <div class="nx-sk__facts">
            <div *ngFor="let f of arr(6)"><span class="nx-sk__line" style="width:50%; height:10px"></span><span class="nx-sk__line" style="width:80%; height:14px"></span></div>
          </div>
          <span class="nx-sk__line" style="width:30%; height:14px; margin-top:8px"></span>
          <div class="nx-sk__box">
            <div class="nx-sk__table-row" *ngFor="let r of arr(3); let i = index" style="grid-template-columns:1fr 1fr 1fr">
              <span class="nx-sk__line" *ngFor="let c of arr(3); let j = index" [style.width.%]="w(i + j, 50, 85)" style="height:12px"></span>
            </div>
          </div>
        </div>
      </ng-container>

      <!-- Tree: indented rows (Hierarchies navigator, As-Was tree) -->
      <ng-container *ngSwitchCase="'tree'">
        <div class="nx-sk__tree-row" *ngFor="let r of arr(rows); let i = index" [style.padding-left.px]="8 + depth(i) * 16">
          <span class="nx-sk__dot"></span>
          <span class="nx-sk__line" [style.width.px]="w(i, 110, 220)" style="height:12px"></span>
          <span class="nx-sk__line" style="width:40px; height:10px"></span>
        </div>
      </ng-container>

      <!-- Timeline: dot + two lines (Recent activity, History, Discussion) -->
      <ng-container *ngSwitchCase="'timeline'">
        <div class="nx-sk__tl-row" *ngFor="let r of arr(rows); let i = index">
          <span class="nx-sk__dot nx-sk__dot--lg"></span>
          <div><span class="nx-sk__line" [style.width.%]="w(i, 60, 90)" style="height:13px"></span>
               <span class="nx-sk__line" style="width:35%; height:10px"></span></div>
        </div>
      </ng-container>

      <!-- Cells: snapshot strip (Home) -->
      <ng-container *ngSwitchCase="'cells'">
        <div class="nx-sk__cells" [style.grid-template-columns]="'repeat(' + cols + ', 1fr)'">
          <div *ngFor="let c of arr(cols)">
            <span class="nx-sk__line" style="width:50%; height:10px"></span>
            <span class="nx-sk__line" style="width:30%; height:26px"></span>
            <span class="nx-sk__line" style="width:60%; height:11px"></span>
          </div>
        </div>
      </ng-container>

      <!-- Facts row: label/value pairs (Sandboxes head) -->
      <ng-container *ngSwitchCase="'facts'">
        <div class="nx-sk__factsrow">
          <div *ngFor="let c of arr(cols)"><span class="nx-sk__line" style="width:70px; height:10px"></span><span class="nx-sk__line" style="width:110px; height:18px"></span></div>
        </div>
      </ng-container>
    </ng-container>
    <span class="nx-visually-hidden">{{ label }}</span>
  `,
})
export class SkeletonComponent {
  @Input() variant: SkeletonVariant = 'list';
  @Input() rows = 5;
  @Input() cols = 4;
  /** Optional CSS grid template for table variant, e.g. '2fr 1fr 1fr 120px'. */
  @Input() columns?: string;
  @Input() label = 'Loading';

  arr(n: number): number[] { return Array.from({ length: n }, (_, i) => i); }
  grid(): string { return this.columns ?? `repeat(${this.cols}, minmax(0, 1fr))`; }
  /** Stable pseudo-random widths so rows don't look identical. */
  w(i: number, min: number, max: number): number { return min + ((i * 37) % (max - min + 1)); }
  depth(i: number): number { return [0, 1, 2, 3, 3, 3, 2, 3, 3, 1, 2, 2][i % 12]; }
}
