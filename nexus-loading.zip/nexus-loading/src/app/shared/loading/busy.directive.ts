import { Directive, ElementRef, Input, OnChanges, Renderer2 } from '@angular/core';

/**
 * Button loading state. Keeps the button width, shows a spinner, blocks double clicks.
 *   <button class="btn-primary" [nxBusy]="comparing" (click)="compare()">Compare</button>
 */
@Directive({ selector: 'button[nxBusy]', standalone: true })
export class BusyDirective implements OnChanges {
  @Input() nxBusy = false;
  private spinner?: HTMLElement;
  constructor(private el: ElementRef<HTMLButtonElement>, private r: Renderer2) {}

  ngOnChanges(): void {
    const b = this.el.nativeElement;
    if (this.nxBusy) {
      b.style.minWidth = b.getBoundingClientRect().width + 'px';
      b.classList.add('is-busy');
      b.setAttribute('aria-busy', 'true');
      b.setAttribute('aria-disabled', 'true');
      if (!this.spinner) {
        this.spinner = this.r.createElement('span');
        this.r.addClass(this.spinner, 'nx-spinner');
        this.r.setAttribute(this.spinner, 'aria-hidden', 'true');
        this.r.insertBefore(b, this.spinner, b.firstChild);
      }
    } else {
      b.classList.remove('is-busy');
      b.removeAttribute('aria-busy');
      b.removeAttribute('aria-disabled');
      b.style.minWidth = '';
      if (this.spinner) { this.r.removeChild(b, this.spinner); this.spinner = undefined; }
    }
  }
}
