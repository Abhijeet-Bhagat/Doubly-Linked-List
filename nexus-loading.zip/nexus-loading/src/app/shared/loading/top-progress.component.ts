import { ChangeDetectionStrategy, Component, DestroyRef, effect, inject, signal, untracked } from '@angular/core';
import { NavigationCancel, NavigationEnd, NavigationError, NavigationSkipped, NavigationStart, Router } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { LoadingService } from './loading.service';

/**
 * Universal loader: a 3px green bar pinned under the green header.
 * - appears only if work lasts > 150ms (no flicker)
 * - once shown, stays at least 300ms
 * - creeps to ~90% while busy, completes to 100% and fades when done
 * Place ONCE in the app shell, directly after the header/context bar.
 */
@Component({
  selector: 'nx-top-progress',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="nx-progress" [class.is-visible]="visible()" role="progressbar"
         aria-label="Loading" [attr.aria-busy]="visible()" [attr.aria-hidden]="!visible()">
      <div class="nx-progress__bar" [style.transform]="'scaleX(' + value() + ')'"></div>
    </div>
  `,
  styleUrls: ['./loading.scss'],
})
export class TopProgressComponent {
  private loading = inject(LoadingService);
  private router = inject(Router);
  readonly visible = signal(false);
  readonly value = signal(0);
  private showTimer?: ReturnType<typeof setTimeout>;
  private creepTimer?: ReturnType<typeof setInterval>;
  private shownAt = 0;

  constructor() {
    // Route changes count as work too (lazy chunks, resolvers).
    this.router.events.pipe(takeUntilDestroyed(inject(DestroyRef))).subscribe((e) => {
      if (e instanceof NavigationStart) this.loading.start();
      if (e instanceof NavigationEnd || e instanceof NavigationCancel || e instanceof NavigationError || e instanceof NavigationSkipped) this.loading.stop();
    });
    effect(() => {
      const busy = this.loading.busy();
      untracked(() => (busy ? this.begin() : this.end()));
    });
  }

  private begin(): void {
    clearTimeout(this.showTimer);
    this.showTimer = setTimeout(() => {
      this.shownAt = Date.now();
      this.value.set(0.08);
      this.visible.set(true);
      clearInterval(this.creepTimer);
      this.creepTimer = setInterval(() => this.value.update((v) => (v < 0.9 ? v + (0.9 - v) * 0.08 : v)), 200);
    }, 150);
  }

  private end(): void {
    clearTimeout(this.showTimer);
    if (!this.visible()) return;
    const wait = Math.max(0, 300 - (Date.now() - this.shownAt));
    setTimeout(() => {
      clearInterval(this.creepTimer);
      this.value.set(1);
      setTimeout(() => { this.visible.set(false); this.value.set(0); }, 250);
    }, wait);
  }
}
