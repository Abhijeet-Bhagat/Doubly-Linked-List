# Nexus – Hierarchies screen · UI specification

**Route:** `/hierarchies` (query `?h=<code>&node=<code>`) · **Header tab:** Hierarchies · **Mockup board:** "Hierarchies (aligned with new Home)" — `Hierarchies-F.dc.html`
**Purpose:** find a node fast, understand where it sits (in this and every other hierarchy), see its properties and history, and add changes to the draft. Must scale to 15+ hierarchies and trees of thousands of nodes.


---

## Part A — Shared foundations (identical on every Nexus screen)

> This part is the same in all 8 screen specs. Do not change any value here for one screen only. If a value here conflicts with something in Part B, Part A wins unless Part B says it overrides it.

### A1. Design tokens

Use these exact values. Do not add new colours, shades, shadows or radii.

| Token | Value | Use |
|---|---|---|
| `--nx-header-bg` | `#044014` | Top header band only. Never used for buttons or highlights in the page body. |
| `--nx-brand` | `#368727` | Every filled primary button, active tab underline in the page body, selected toggle segment, switch "on", checkbox fill, selected day bar, timeline dot "approved", selected-row left edge. White text on it (contrast 4.5:1). |
| `--nx-link` | `#2B6A1F` | All text links (underlined, `text-underline-offset: 2px`), green tag text, positive status text. |
| `--nx-link-hover` | `#1E4F15` | Link hover. |
| `--nx-tint` | `#F3F6F1` | Selected row background, "new value" cell background, current-step background. |
| `--nx-tint-2` | `#E6EFE2` | Selected option background in dropdown lists, hierarchy icon tile. |
| `--nx-tint-3` | `#E8F1E5` | Draft-count badge background; sandbox strip background. |
| `--nx-tint-border` | `#A8CF9C` | Border of green outlined tags; header active-tab underline; header badge background. |
| `--nx-tint-border-2` | `#DCE6D8` / `#C5D9BE` | Border of pale-green boxes (draft callout, sandbox strip). |
| `--nx-page` | `#F9F7F5` | Page background under everything below the header. |
| `--nx-surface` | `#FFFFFF` | Panels, inputs, menus. |
| `--nx-surface-2` | `#FCFBFA` | Table header rows, group header rows, inset boxes, separator rows. |
| `--nx-border` | `#E5E1DC` | Panel borders, table borders, tab-row bottom border. |
| `--nx-divider` | `#EEEAE5` | Row dividers inside panels, section dividers. |
| `--nx-divider-soft` | `#F1EEEA` | Very light row dividers (property rows), neutral chip background. |
| `--nx-control-border` | `#C9C4BE` | Input/select/outline-button borders, unselected switch track. |
| `--nx-text` | `#141414` | Primary text. |
| `--nx-text-2` | `#5C5C5C` | Secondary text, field labels, meta lines. |
| `--nx-text-3` | `#8A8580` | Tertiary text: codes under names, counts in tabs, timestamps, placeholders for empty values. |
| `--nx-muted-dot` | `#B5AFA8` | Neutral timeline dots, leaf dots. |
| `--nx-danger` | `#B42318` | Only: overdue, errors, conflicts, Reject / Delete / Discard-sandbox actions. Never decorative. |
| `--nx-danger-border` | `#E8B4AE` | Border of a red outlined tag / blocked card. |
| `--nx-notify` | `#F2B33D` | Only the notification-count bubble in the header. |

**Colour rules (hard):**
1. One accent: green. No blue, purple or amber anywhere in the page body.
2. A change type (added, moved, renamed …) is shown with **words**, never a colour per type.
3. Red appears only when something is wrong or destructive.
4. Old value = `--nx-text-3` + `line-through`. New value = `font-weight: 600` on `--nx-tint`.

### A2. Typography

- Font stack: `'Fidelity Sans', 'Hind', Helvetica, Arial, sans-serif`. Load Hind 400/500/600/700 from Google Fonts as the fallback; if the app already ships Fidelity Sans (as the Fidelity Shares app does), use it.
- No monospace font anywhere (codes use the normal font).
- Base text colour `--nx-text`.

| Role | Size / weight | Notes |
|---|---|---|
| Page title (h1) | 30px / 700, letter-spacing −0.01em | One per page. Exception: Hierarchies uses 28px. |
| Detail title (h2 inside a panel) | 28px / 700, line-height 1.25 | Selected item's name. Hierarchies node name 30px. |
| Section title (h3) | 16px / 700 | "Request details", "What changed" … sentence case. |
| Panel heading (h2 in a list panel) | 18px / 700 | "Needs your attention", "Recent activity" … |
| Group header in a list | 14px / 700 + count 13px `--nx-text-3` | On `--nx-surface-2` background. |
| Body | 14–15px / 400 | Row titles 15px / 600. |
| Field label | 13px / 600 `--nx-text-2`, sentence case | "Hierarchy", "From version" … Never ALL CAPS. |
| Meta line | 13px / 400 `--nx-text-2` or `--nx-text-3` | |
| Tiny caps label | 12px / 700, letter-spacing 0.08em, `--nx-text-3` | Only allowed on Home snapshot labels, Hierarchies "WHERE IT LIVES"/property category headers, dropdown group headers (PRIMARY / ALTERNATES, Finance/HR column groups). Nowhere else. |
| Big fact value | 18–20px / 700 | Facts rows (Sandboxes, Versions). |

Copy rules: sentence case; no exclamation marks; no "AI-style" helper sentences under titles. A line under a page title is allowed only when it states live state (e.g. "3 requests need your decision · 1 overdue"). Use `·` (middle dot with spaces) to join short facts.

### A3. Shape, spacing, elevation

| Element | Radius | Height | Border |
|---|---|---|---|
| Panel / card / table container | 8px | — | 1px `--nx-border` |
| Input, select, date, textarea, joined toggle group, square icon button | 4px | 36px (38px for page-level search) | 1px `--nx-control-border` |
| Button (filled or outline) | 999px (pill) | 38px default, 34px in bars, 32px in rows/cards | outline = 1px `--nx-control-border`, white bg |
| Small tag (status/ownership) | 4px | auto, padding 1px 8px, 13px/600 | 1px tint-border |
| Menu / popover | 6–8px | — | 1px `--nx-border` or `--nx-control-border`, shadow `0 8px 24px rgba(0,0,0,0.10)` |
| Count badge (draft) | 999px | 26px min-width | none |

- Page content column: `max-width: 1320px; margin: 0 auto; padding: 26px 24px 28px; gap: 20px` (vertical stack). Hierarchies uses `padding: 24px; gap: 18px`.
- Inside panels: horizontal padding 20px (lists) / 28px (detail areas); rows 14px vertical padding.
- No shadows on panels. Shadows only on popovers/menus, the sticky draft bar (`0 -2px 8px rgba(0,0,0,0.04)`), and toasts.
- Selected row pattern (used everywhere): `background: --nx-tint; box-shadow: inset 3px 0 0 --nx-brand;` unselected rows white.

### A4. Components (reuse exactly)

**A4.1 Primary button** — bg `--nx-brand`, text white 14px/600, pill, 38px, padding 0 20px, no border.
**A4.2 Secondary button** — white bg, 1px `--nx-control-border`, text `--nx-text` 14px/600, pill.
**A4.3 Danger text button** — transparent, no border, text `--nx-danger` 14px/600 (Reject, Discard sandbox, Withdraw).
**A4.4 Danger filled** — bg/border `--nx-danger`, white text (only the confirm step of Reject).
**A4.5 Text link** — `--nx-link`, underline, offset 2px, 13–14px.
**A4.6 Select** — `appearance: none`, 36px, 4px radius, padding `0 32px 0 10px`, 14px/600, chevron SVG 12px stroke `#5C5C5C` 2.4 absolutely positioned right 12px, `pointer-events: none`.
**A4.7 Joined toggle (segmented)** — container `display:inline-flex; border:1px solid --nx-control-border; border-radius:4px; overflow:hidden`. Segments 34px (30px in context bar, 28px small) tall, padding 0 14px, 14px/600; selected = `--nx-brand` bg + white text; unselected = white + `--nx-text`; every segment after the first has `border-left: 1px solid --nx-control-border`. `aria-pressed` on each.
**A4.8 Switch** — `role="switch" aria-checked`, track 34×20 radius 999, on `--nx-brand` / off `--nx-control-border`, knob 16×16 white, left 2px (off) / 16px (on), shadow `0 1px 2px rgba(0,0,0,.2)`; label text 14px to its right, gap 10px.
**A4.9 Tab row (in-panel)** — `role="tablist"`, row padding `0 12px`, gap 4px, bottom border 1px `--nx-border`. Tab: 46px tall (44px on Sandboxes), padding 0 10px, `border-bottom: 3px solid` (`--nx-brand` when selected, transparent otherwise), label 14px weight 700 selected / 500 not, colour `--nx-text` selected / `--nx-text-2` not; count after label 13px/400 `--nx-text-3` (red/700 when it represents blocking problems).
**A4.10 Master–detail split** — single panel (A3), internal grid `grid-template-columns: <list width> minmax(0,1fr)`, list column `border-right: 1px solid --nx-border`. List widths: Compare/Worklist 400px, Versions none (table), Sandboxes 340px, As-Was 400px (separate panels).
**A4.11 List row (button)** — full width, `display:flex; flex-direction:column; gap:3–4px; padding:14px 20px; border-bottom:1px solid --nx-divider; text-align:left`, title 15px/600, then 1–2 meta lines. Selected pattern from A3. `aria-current="true"` when selected.
**A4.12 Before/after table** — container A3; header row on `--nx-surface-2`, 13px/600 `--nx-text-2`, cell padding 10px 12–16px; body rows 14px, top border `--nx-divider` from the 2nd row; Before cell `--nx-text-3` + line-through (no strike when the before value is "—"/"New"/"Not in live"); After cell 600 on `--nx-tint`.
**A4.13 Timeline** — container `position:relative; padding-left:22px`; vertical line 2px `--nx-divider` at left 5px; each item: dot 12×12 circle, 2px white border, `box-shadow:0 0 0 1px <dot colour>`, placed at left −22px top 4–5px; text 14px/600 then meta 12px `--nx-text-3`. Dot colours: approved `--nx-brand`, comment `--nx-text-3`, other/system `--nx-muted-dot`.
**A4.14 Toast** — fixed, bottom 76px (24px on pages without draft bar), centred, bg `--nx-text`, white 14px, radius 4px, padding 10px 16px, auto-hide 2500ms, `role="status"`. Worklist toast adds an **Undo** button (30px, radius 4px, bg rgba(255,255,255,.14)).
**A4.15 Empty state** — centred in its area, title 18px/700, one line 14px `--nx-text-2`, padding 40–56px.
**A4.16 Status tag** — inline, 13px/600, 1px border, 4px radius, padding 1px 8px. Green variant: text `--nx-link`, border `--nx-tint-border`. Neutral: text `--nx-text-2`, border `--nx-control-border`. Red: text `--nx-danger`, border `--nx-danger-border`.

### A5. App shell (top of every page)

Root: `min-height:100vh; background:--nx-page; display:flex; flex-direction:column; font-family: A2`.

**A5.1 Header band** (`<header>`, bg `--nx-header-bg`, white text)
- Row 1: inner `max-width:1320px; margin:0 auto; padding:12px 24px 0; display:flex; align-items:center; gap:16px`:
  1. Logo placeholder: dashed 1.5px rgba(255,255,255,.7) box, radius 4px, padding 2px 8px, "LOGO" 12px/700 (replace with the real Fidelity logo asset).
  2. "Nexus" 24px/700.
  3. "Master Data Central" 13px rgba(255,255,255,.75).
  4. Flexible spacer.
  5. Help icon button 32×32 (question-mark-in-circle icon 20px, stroke 1.7) `aria-label="Help"`.
  6. Notifications icon button 32×32 (bell icon) with count bubble: absolute top 1px right 1px, min 15×15, radius 999, bg `--nx-notify`, text `#141414` 10px/700. `aria-label="Notifications, 3 new"`.
  7. Environment pill "Development": 12px, 1px rgba(255,255,255,.5) border, radius 999, padding 3px 12px.
  8. Vertical divider 1×22 rgba(255,255,255,.25).
  9. User button: avatar circle 30×30 rgba(255,255,255,.16) with initials 12px/700 ("VA"), then name 13px ("E2E Version Admin").
- Row 2 — main navigation `<nav aria-label="Main">`: `max-width:1320px; margin:0 auto; padding:4px 16px 0; height:42px; display:flex; gap:4px`. Each tab is an `<a>`: padding 0 12px, 14px, `border-bottom:3px solid` (`--nx-tint-border` when current, transparent otherwise), weight 700 current / 500 other, colour white current / rgba(255,255,255,.78) other, `aria-current="page"` on current.
  - Tab order: **Home · Hierarchies · Worklist [3] · Queries · Compare · As-Was · Sandboxes · Versions** (the Admin entry used in early boards is replaced by Sandboxes + Versions).
  - Worklist badge: 11px/700, text `--nx-header-bg`, bg `--nx-tint-border`, radius 999, padding 0 6px, line-height 16px. Shows the number of requests waiting for the user's decision; hidden when 0.

**A5.2 Context bar** (white, bottom border 1px `--nx-border`): inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:24px`.
1. Label "Version" 13px `--nx-text-2` + select (32px, 4px radius, 13px/600): options "2026-11 · Working", "2026-10 · Finalized". Changing it re-scopes every screen.
2. Label "Viewing as of" + date input (32px, 4px radius, 13px). Default today.
3. "Work in" + joined toggle (A4.7, 30px, 13px): **Live data** | **Sandbox**. Selected = `--nx-brand`.
4. Spacer, then link "Manage versions" (13px, `--nx-link`) → Versions screen.

**A5.3 Sticky draft bar** (all screens except Sandboxes): `position:sticky; bottom:0; background:#FFF; border-top:1px solid --nx-border; box-shadow:0 -2px 8px rgba(0,0,0,.04); z-index:20`. Inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:14px; font-size:14px`.
1. Count badge 26px pill: with drafts bg `--nx-tint-3` text `--nx-link`; empty bg `--nx-divider-soft` text `--nx-text-2`. 13px/700.
2. Text: **"Changes in your draft"** (700; singular "Change in your draft"; empty "No changes in your draft") + ` · nothing changes until approved` (`--nx-text-2`; empty: "· edits you make are collected here").
3. Spacer.
4. Link-style button "View changes" / "Hide changes" toggles a popover (`aria-expanded`).
5. Secondary 34px "Discard".
6. Primary 34px "Review and submit".
- When empty, Discard and Review and submit get `aria-disabled="true"` and `opacity:.5` (do not use the boolean `disabled` attribute binding).
- Popover: absolute, bottom calc(100% + 8px), left 24px, width 480px, radius 8px, shadow A3, padding 8px 0. Header "Changes in your draft" 13px/600 `--nx-text-2` padding 6px 16px. Each item row min-height 42px, top divider, text button 14px (clicking navigates to the node), remove × icon button 30×30 `aria-label="Remove from draft"`. Empty: "Your draft is empty." 14px `--nx-text-2`.
- Example items: "Move 34307 · AGQNT → AGCOE in ORGTL", "Edit 34301 · name “QNT Analytics Platform”".

### A6. Accessibility & behaviour baseline
- Every input has a `<label>` (visually hidden class when the design shows none: `position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)`).
- Tabs use `role="tablist"/"tab"` + `aria-selected`; segmented toggles use `aria-pressed`; switches `role="switch"` + `aria-checked`; list selection `aria-current`.
- Decorative icons/dots `aria-hidden="true"`; meaning is always also in text.
- Disabled-looking actions use `aria-disabled` + reduced opacity + a visible reason somewhere nearby.
- Text never truncates with ellipsis in lists/detail; long names wrap (`overflow-wrap:anywhere` on names/paths).
- All numbers use `en-US` grouping (2,818). Dates: "18 Nov 2026"; times 24h "10:30".

### A7. Shared demo data (use the same values on every screen)
- User: E2E Version Admin (`e2e_vadmin`, initials VA). Other people: u_editor1, u_approver1, u_admin, E2E Steward.
- Versions: **2026-11** Working (business date 18 Nov 2026, created from 2026-10), **E2E working** Working (15 Nov 2026), **2026-10** Finalized (28 Oct 2026, frozen 18 Nov 2026 06:22).
- Hierarchies: ORGTL "Total Fidelity" Primary 2,818 nodes 14 levels; ORGTP "Total Fidelity Technology" Alternate 516/12; AMBUS "Asset Management BU Alternate" Alternate 1,501/12; plus 12 alternates: E2E_H E2E Legal Group 142/8, E2E_MGMT E2E Management View 96/7, FINRPT Finance Reporting 1,210/10, LEGENT Legal Entities 388/6, GEOREG Geographic Regions 240/5, CCOWN Cost Centre Owners 2,236/9, HRORG HR Organisation 1,890/11, TAXREP Tax Reporting 610/8, OPSDEL Operations Delivery 744/9, PRODLN Product Lines 455/7, RISKV Risk View 302/6, PROJTL Project Portfolio 128/5 (15 total).
- Key nodes: ORGTL › OC005 Asset Management › AM Asset Management Executive › AMT Asset Management Technology › AMQNT Quant Technology › {AGCOE AM AI Center of Excellence, AGQNT US Quant Technology}. Leaves under AGQNT: 31679 UK QNT Tech, 34295 QNT Engineering, 34299 QNT Leadership, 34301 QNT Analytics Platform, 34322 QNT Contingent (Inactive). 34307 QNT Quant Dev (under AGCOE in ORGTL; under AGQNT in ORGTP/AMBUS).
- Draft (pending, not submitted): Move 34307 AGQNT → AGCOE in ORGTL; Rename 34301 → "QNT Analytics Platform".
- Integrity rules: CODE_UNIQUE, PARENT_EXISTS, PARENT_IS_LIMB, NO_CYCLES.


---

## Part B — Hierarchies screen

### B1. Page structure
```
[A5.1 Header] [A5.2 Context bar]
┌ content column (max 1320, padding 24, gap 18) ─────────────────────────────────┐
│ B2 Title row:  "Hierarchies"  Find a node, see where it lives, propose a change.  Export │
│ ┌ B3 Navigator (400px) ┐  ┌ B4 Node panel (flex 1) ──────────────────────────┐ │
│ │ hierarchy picker      │  │ path ribbon                                      │ │
│ │ node search           │  │ name / meta            [Edit details][Move][⋯]  │ │
│ │ "Showing n" Hide inact│  │ pending-in-draft callout (when relevant)         │ │
│ │ tree                  │  │ inline edit form (when open)                     │ │
│ │                       │  │ WHERE IT LIVES list                              │ │
│ │                       │  │ tabs: Properties | Children | History            │ │
│ └───────────────────────┘  └──────────────────────────────────────────────────┘ │
└────────────────────────────────────────────────────────────────────────────────┘
[A5.3 Draft bar]
```
Two panels side by side: `display:flex; gap:20px; align-items:stretch; flex:1; min-height:660px`.

### B2. Title row
`display:flex; align-items:baseline; gap:14px`:
- h1 **28px**/700 "Hierarchies".
- 14px `--nx-text-2`: "Find a node, see where it lives, propose a change."
- spacer; link 13px "Export" (exports the current hierarchy as CSV).

### B3. Navigator panel (left)
`<section aria-label="Navigator">`, width 400px fixed, panel style, `display:flex; flex-direction:column; overflow:hidden`.

**B3.1 Top block** `padding:14px 14px 12px; display:flex; flex-direction:column; gap:10px; border-bottom:1px solid --nx-divider`.

**(a) Hierarchy picker** — a button that opens a listbox popover (this replaces any tab strip of hierarchies so it scales to 15+).
- Button: `display:flex; align-items:center; gap:10px; width:100%; min-height:48px; padding:6px 12px; border:1px solid (open ? --nx-brand : --nx-control-border); border-radius:6px; background:#fff; text-align:left`. `aria-haspopup="listbox" aria-expanded`.
  1. Icon tile 32×32, radius 6, bg `--nx-tint-2`, colour `--nx-brand`, hierarchy (org-chart) icon 18px.
  2. Text column: hierarchy name 15px/700 line-height 1.25 ("Total Fidelity"); under it 12px `--nx-text-2` "ORGTL · Primary · 2,818 nodes · 14 levels".
  3. 12px `--nx-text-2` nowrap "1 of 15".
  4. Chevron 14px (down when closed, up when open).
- Popover: absolute top 54px, left/right 0, white, 1px `--nx-control-border`, radius 6, shadow `0 10px 24px rgba(0,0,0,.14)`, z 30, `max-height:420px`, column.
  - Filter box: padding 10px, bottom divider; search input 34px, 4px radius, placeholder "Find a hierarchy" (hidden label same).
  - Listbox (`role="listbox" aria-label="Hierarchies"`, scrolls, padding 4px 0 6px):
    - Group header tiny caps 11px/700 0.08em `--nx-text-3`, padding 10px 14px 4px: "PRIMARY" then "ALTERNATES · <n>".
    - Option (`role="option" aria-selected`): `display:flex; align-items:center; gap:10px; padding:8px 14px`; selected bg `--nx-tint-2`, else white.
      - code 13px/700 fixed width 74px
      - name 14px flex 1
      - green dot 7×7 `--nx-brand` **only if the hierarchy contains the selected node** (`title="Contains the selected node"`)
      - node count 12px `--nx-text-3` right-aligned width 72px ("2,818 nodes")
    - No match: 13px `--nx-text-2` "No hierarchy matches “<q>”."
  - Footer: padding 8px 14px, top divider, 12px `--nx-text-2`: green dot + "Contains <selected node code>" (legend).
  - Picking an option: switches hierarchy, closes popover, clears filter, keeps the same node selected if it exists there (else selects the hierarchy top node).

**(b) Node search**
- Input 38px, 4px radius, padding `0 12px 0 34px`, search icon left, placeholder "Find by code or name", hidden label "Find a node".
- At ≥2 characters a results popover appears: absolute top 42px, full width, radius 6, shadow `0 8px 20px rgba(0,0,0,.12)`, z 20. Up to **6** results, each a button with `padding:9px 12px`, top divider from 2nd: line 1 14px "**<name>** <code in --nx-text-2>"; line 2 12px `--nx-text-2` full path "ORGTL / OC005 / AM / AMT / AMQNT / AGCOE / 34307". Picking selects the node, expands its path, clears the box. No results: "No nodes match “<q>”."

**(c) Count + filter row** `display:flex; align-items:center; gap:8px; 12px --nx-text-2`:
- "Showing <visible rows> of <total nodes> nodes" (e.g. "Showing 14 of 2,818 nodes").
- spacer
- Checkbox label 13px `--nx-text`: checkbox 14×14 `accent-color:--nx-brand` + "Hide inactive". When on, inactive nodes are hidden except the selected one.

**B3.2 Tree** `role="tree" aria-label="<hier code>"`, `flex:1; overflow:auto; padding:6px 6px 10px`. Rendered rows only for expanded branches (virtualise for >500 visible rows).
- Row (`role="treeitem" aria-selected`): `display:flex; align-items:center; min-height:34px; border-radius:4px`; selected bg `--nx-tint-2`.
  1. Indent spacer width `4 + depth×16` px with vertical guide lines: `background-image: repeating-linear-gradient(to right, transparent 0 11px, #E5E1DC 11px 12px, transparent 12px 16px)` (none at depth 0).
  2. Expander 22×22: chevron (right closed / down open), colour `--nx-text-2` (selected row: `--nx-header-bg`), `aria-label="Expand|Collapse <code>"`, `aria-expanded`. Leaf rows show instead a 5×5 dot (`#9E9890`, inactive `#D6D1CB`).
  3. Select button (flex 1, `align-items:baseline; gap:8px; padding:6px 8px 6px 2px`):
     - name 14px (selected 700, else 400) line-height 1.35, `overflow-wrap:anywhere` (never truncated)
     - code 12px (`--nx-text-3`; selected `--nx-link`)
     - spacer
     - **draft marker**: 7×7 white circle with `box-shadow: inset 0 0 0 2px --nx-brand`, `title="Pending in your draft"`, only on nodes with a pending draft change in this hierarchy
     - collapsed-child count 12px `--nx-text-3` (shown only when the node has children and is collapsed).
  - Inactive nodes: text `--nx-text-3`.
- Default: the path to the selected node is expanded. Expansion state is remembered per hierarchy.
- Keyboard: ↑/↓ move, →/← expand/collapse, Enter selects.

### B4. Node panel (right)
`<section aria-label="Node">`, panel, `flex:1; min-width:0; display:flex; flex-direction:column; overflow:hidden`. Top area `padding:20px 26px 0; column; gap:16px`.

**B4.1 Path ribbon** `<nav aria-label="Path">`, wraps (`row-gap:8px`). For each ancestor + the node:
- Pill button 28px tall, padding `0 10px 0 4px`, radius 999, 13px, `title=<name>`:
  - level badge: min 20×20 circle, 11px/700, number = depth (1 = top); ancestors bg `#F3EFEA` text `--nx-text-2`; current bg rgba(255,255,255,.2) text white
  - then the code.
  - Ancestors: white bg, 1px `--nx-border`, 500 weight, `--nx-text`. Current (`aria-current="page"`): bg `--nx-brand`, border `--nx-brand`, white, 700.
- Between pills a 14×1 line `--nx-control-border`.
- Clicking an ancestor selects it.

**B4.2 Identity row** `display:flex; align-items:flex-start; gap:20px; flex-wrap:wrap`:
- Left (`flex:1 1 340px`): h2 30px/700 line-height 1.15 node name (e.g. "QNT Quant Dev"); meta 15px `#4A4A4A` "34307 · Leaf · Quant development · **Active**" — status 600 in `--nx-link` (Active) or `--nx-text-3` (Inactive).
- Right actions (gap 8px):
  1. Primary 38px "Edit details" (toggles B4.4).
  2. Secondary 38px "Move" (opens a parent picker that only lists valid limbs; invalid parents are not selectable — rule PARENT_IS_LIMB / NO_CYCLES).
  3. Secondary 38px "Add child" — **only for Limb nodes**.
  4. Round 38×38 outline "More actions" button (⋯ icon), `aria-haspopup="menu"`. Menu (`role="menu"`, absolute right 0 top 44px, width 250px, radius 6, shadow) items 14px padding 9px 14px:
     - "Add to another hierarchy"
     - "Inactivate"
     - "Remove from <hier>"
     - divider
     - "Delete from all hierarchies" in `--nx-danger`.

**B4.3 Pending-in-draft callout** (only when the selected node has a draft change relevant to this hierarchy): `display:flex; align-items:center; gap:14px; flex-wrap:wrap; background:--nx-tint; border:1px solid #DCE6D8; border-radius:6px; padding:12px 14px`:
- draft marker 8×8
- "Pending in your draft" 14px/700
- chips: old value chip (white, 1px `#DCE6D8`, radius 999, padding 2px 10px, `#6B6B6B`, line-through) → arrow icon → new value chip (white, 1px `--nx-control-border`, 700)
- scope text 13px: "new parent in ORGTL only" / "new name in every hierarchy"
- spacer; link-button "Undo" (removes the change from the draft).
- Data: 34307 → "AGQNT" → "AGCOE" · "new parent in ORGTL only". 34301 → "QNT Analytics" → "QNT Analytics Platform" · "new name in every hierarchy".

**B4.4 Inline edit form** (when "Edit details" toggled): box 1px `--nx-control-border`, radius 6, padding 14, bg `--nx-surface-2`, column gap 12.
- Two fields side by side (`flex:1 1 240px`, gap 14): "Name" (label 13px/600; input 38px, 4px radius, maxlength 60) and "Description".
- Footer row: 13px `--nx-text-2` hint "A new name shows in every hierarchy this node is in." (flex 1); secondary 36px "Cancel"; primary 36px "Add to draft".
- Saving never writes to live data; it adds to the draft and shows B4.3.

**B4.5 WHERE IT LIVES** (column gap 8):
- Header: tiny caps "WHERE IT LIVES" + 13px `--nx-text-2` "In 7 of 15 hierarchies".
- List container 1px `--nx-border`, radius 6. Row button (`aria-current` on the current hierarchy): `display:grid; grid-template-columns:84px minmax(0,1fr) 132px 64px minmax(0,1.1fr); gap:12px; padding:9px 12px; align-items:center`; top divider from 2nd row; current row = selected pattern (`--nx-tint` + 3px `--nx-brand` edge).
  1. code 13px/700
  2. hierarchy name 13px `#3D3D3D`
  3. **depth bar**: one 6px-tall segment per level of that hierarchy (flex 1 each, gap 2px, radius 2): filled up to the node's level (`--nx-brand` on the current hierarchy, `#8DB487` on others), the rest `--nx-divider`. `aria-hidden` (the level text carries the meaning).
  4. level 13px/700 "7 / 14"
  5. parent 12px `--nx-text-2` "under AGCOE · AM AI Center of Excellence" (or "Top node").
- Order: current hierarchy first, then others in master order. Show **4** rows; if more, link-button 13px "Show all 7" / "Show fewer".
- Clicking a row switches the navigator to that hierarchy (same node).
- No percentages anywhere.

**B4.6 Tabs** `role="tablist" aria-label="Node information"`, `display:flex; gap:22px; padding:0 26px; margin-top:18px; border-bottom:1px solid --nx-divider`. Tab 40px, no padding, `border-bottom:2px solid` (`--nx-brand` selected), label 14px + count 400 `--nx-text-3`:
- "Properties 9", "Children <n>", "History <n>".

**B4.7 Tab panel** `role="tabpanel"`, `flex:1; overflow:auto; padding:8px 26px 22px`.

*Properties* — grouped list:
- Category header: tiny caps, padding 16px 0 6px: "FINANCE", "HR", "REPORTING".
- Row: `display:grid; grid-template-columns:minmax(0,1fr) minmax(0,.8fr) minmax(0,1fr) 80px; gap:12px; min-height:40px; border-bottom:1px solid --nx-divider-soft; font-size:14px; align-items:center`:
  1. label `#3D3D3D`
  2. value 700
  3. source 13px `--nx-text-3` in plain words: "Derived from code" / "Inherited from " + link-button to the ancestor code (e.g. **AMT**, clicking selects that ancestor) / "Set on this node" / "Default"
  4. action right-aligned 13px: "Override" or "Edit" as underlined `--nx-link` links; "Derived" as plain text `--nx-muted-dot`.
- Rows (data for 34307):
  - FINANCE: Cost centre 34307 (Derived from code, Derived); Finance country US (Inherited from AMT, Override); Oracle accounting currency USD (AMT, Override); Oracle GL company 0444 (AMT, Override); Oracle operating ledger L100 (AMT, Override).
  - HR: Standard working hours 40.00 (Inherited from ORGTL, Override); HR flag Y (Set on this node, Edit).
  - REPORTING: Reporting currency USD (Default, Override); Include in reporting Y (Default, Override).

*Children* — rows (button, select child): `display:flex; align-items:baseline; gap:10px; min-height:40px; padding:10px 0; border-bottom:1px solid --nx-divider-soft`: name 14px/600, code 12px `--nx-text-3`, spacer, note 12px `--nx-text-3` = "In your draft" / "Inactive" / "<n> below" (limb) / "Leaf". Empty: 14px `--nx-text-2` "Leaf nodes have no children." or "No children yet."

*History* — timeline (A4.13), container padding 14px 0 0 22px. Items newest first:
- (if draft) "Move 34307 from AGQNT to AGCOE in ORGTL" — "In your draft · not submitted" — dot `--nx-muted-dot` (outlined style allowed)
- "HR flag set to Y" — "5 Nov 2026 · approved by u_approver1" — green
- "Copied from the 2026-10 baseline" — "1 Nov 2026 · system" — grey.

### B5. Behaviour summary
- URL keeps `h` and `node`; back/forward restores them.
- Version/as-of in the context bar change the tree to that picture (read only when a Finalized version is selected: hide Edit/Move/Add child/⋯ and show the tag "Read only" next to the title).
- Sandbox workspace: tree shows sandbox data and the Sandboxes strip (see Sandboxes spec) appears under the context bar.
- All edits go to the draft (A5.3). Nothing writes live data directly.

### B6. Acceptance checklist
- [ ] 15 hierarchies reachable from the picker with filter and Primary/Alternates groups; "1 of 15" shown.
- [ ] Green dot marks hierarchies containing the node.
- [ ] Names wrap, never cut off, in tree, ribbon titles and lists.
- [ ] Draft marker is a green ring (no amber).
- [ ] Where-it-lives shows depth bars + "7 / 14" text, max 4 rows then "Show all".
- [ ] Property source written in words with clickable ancestor.
