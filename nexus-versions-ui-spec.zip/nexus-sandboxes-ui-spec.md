# Nexus – Sandboxes screen · UI specification

**Route:** `/sandboxes` and `/sandboxes/:id?tab=<changes|diff|conflicts|validation>` · **Header tab:** Sandboxes · **Mockup board:** "Sandboxes (new)" — `Sandboxes.dc.html`
**Purpose:** private drafts where a user tries changes against a copy of live data, resolves conflicts and validation problems, then submits the whole sandbox as one request. Text is deliberately minimal: labels and numbers, no explanatory paragraphs.

Principles this screen must honour: live vs sandbox always distinguishable; sandbox name, change count and effective date always visible while working; proposed changes separate from history; conflicts ≠ validation errors; before/after at item and property level; owner vs viewer obvious; submit never implies a live update; show why submit is unavailable; text labels with every colour/icon; clear return-to-live; refresh/concurrency shown as recoverable; capacity shown before it blocks; changed items look the same in tree, panel, tray and diff.

**Note:** this screen does **not** show the A5.3 draft bar. A sandbox has its own submit.


---

## Part A — Shared foundations (identical on every Nexus screen)

> This part is the same in all 8 screen specs. Do not change any value here for one screen only. If a value here conflicts with something in Part B, Part A wins unless Part B says it overrides it.

### A1. Design tokens

Use these exact values. Do not add new colours, shades, shadows or radii.

| Token | Value | Use |
|---|---|---|
| `--nx-header-bg` | `#044014` | Top header band only. Never used for buttons or highlights in the page body. |
| `--nx-brand` | `#368727` | Every filled primary button, active tab underline in the page body, selected toggle segment, switch "on", checkbox fill, selected day bar, timeline dot "approved", selected-row left edge. White text on it (contrast 4.5:1). |
| `--nx-link` | `#2B6A1F` | All text links (underlined, `text-underline-offset: 2px`), green tag text, positive status text. |
| `--nx-link-hover` | `#1E4F15` | Link hover. |
| `--nx-tint` | `#F3F6F1` | Selected row background, "new value" cell background, current-step background. |
| `--nx-tint-2` | `#E6EFE2` | Selected option background in dropdown lists, hierarchy icon tile. |
| `--nx-tint-3` | `#E8F1E5` | Draft-count badge background; sandbox strip background. |
| `--nx-tint-border` | `#A8CF9C` | Border of green outlined tags; header active-tab underline; header badge background. |
| `--nx-tint-border-2` | `#DCE6D8` / `#C5D9BE` | Border of pale-green boxes (draft callout, sandbox strip). |
| `--nx-page` | `#F9F7F5` | Page background under everything below the header. |
| `--nx-surface` | `#FFFFFF` | Panels, inputs, menus. |
| `--nx-surface-2` | `#FCFBFA` | Table header rows, group header rows, inset boxes, separator rows. |
| `--nx-border` | `#E5E1DC` | Panel borders, table borders, tab-row bottom border. |
| `--nx-divider` | `#EEEAE5` | Row dividers inside panels, section dividers. |
| `--nx-divider-soft` | `#F1EEEA` | Very light row dividers (property rows), neutral chip background. |
| `--nx-control-border` | `#C9C4BE` | Input/select/outline-button borders, unselected switch track. |
| `--nx-text` | `#141414` | Primary text. |
| `--nx-text-2` | `#5C5C5C` | Secondary text, field labels, meta lines. |
| `--nx-text-3` | `#8A8580` | Tertiary text: codes under names, counts in tabs, timestamps, placeholders for empty values. |
| `--nx-muted-dot` | `#B5AFA8` | Neutral timeline dots, leaf dots. |
| `--nx-danger` | `#B42318` | Only: overdue, errors, conflicts, Reject / Delete / Discard-sandbox actions. Never decorative. |
| `--nx-danger-border` | `#E8B4AE` | Border of a red outlined tag / blocked card. |
| `--nx-notify` | `#F2B33D` | Only the notification-count bubble in the header. |

**Colour rules (hard):**
1. One accent: green. No blue, purple or amber anywhere in the page body.
2. A change type (added, moved, renamed …) is shown with **words**, never a colour per type.
3. Red appears only when something is wrong or destructive.
4. Old value = `--nx-text-3` + `line-through`. New value = `font-weight: 600` on `--nx-tint`.

### A2. Typography

- Font stack: `'Fidelity Sans', 'Hind', Helvetica, Arial, sans-serif`. Load Hind 400/500/600/700 from Google Fonts as the fallback; if the app already ships Fidelity Sans (as the Fidelity Shares app does), use it.
- No monospace font anywhere (codes use the normal font).
- Base text colour `--nx-text`.

| Role | Size / weight | Notes |
|---|---|---|
| Page title (h1) | 30px / 700, letter-spacing −0.01em | One per page. Exception: Hierarchies uses 28px. |
| Detail title (h2 inside a panel) | 28px / 700, line-height 1.25 | Selected item's name. Hierarchies node name 30px. |
| Section title (h3) | 16px / 700 | "Request details", "What changed" … sentence case. |
| Panel heading (h2 in a list panel) | 18px / 700 | "Needs your attention", "Recent activity" … |
| Group header in a list | 14px / 700 + count 13px `--nx-text-3` | On `--nx-surface-2` background. |
| Body | 14–15px / 400 | Row titles 15px / 600. |
| Field label | 13px / 600 `--nx-text-2`, sentence case | "Hierarchy", "From version" … Never ALL CAPS. |
| Meta line | 13px / 400 `--nx-text-2` or `--nx-text-3` | |
| Tiny caps label | 12px / 700, letter-spacing 0.08em, `--nx-text-3` | Only allowed on Home snapshot labels, Hierarchies "WHERE IT LIVES"/property category headers, dropdown group headers (PRIMARY / ALTERNATES, Finance/HR column groups). Nowhere else. |
| Big fact value | 18–20px / 700 | Facts rows (Sandboxes, Versions). |

Copy rules: sentence case; no exclamation marks; no "AI-style" helper sentences under titles. A line under a page title is allowed only when it states live state (e.g. "3 requests need your decision · 1 overdue"). Use `·` (middle dot with spaces) to join short facts.

### A3. Shape, spacing, elevation

| Element | Radius | Height | Border |
|---|---|---|---|
| Panel / card / table container | 8px | — | 1px `--nx-border` |
| Input, select, date, textarea, joined toggle group, square icon button | 4px | 36px (38px for page-level search) | 1px `--nx-control-border` |
| Button (filled or outline) | 999px (pill) | 38px default, 34px in bars, 32px in rows/cards | outline = 1px `--nx-control-border`, white bg |
| Small tag (status/ownership) | 4px | auto, padding 1px 8px, 13px/600 | 1px tint-border |
| Menu / popover | 6–8px | — | 1px `--nx-border` or `--nx-control-border`, shadow `0 8px 24px rgba(0,0,0,0.10)` |
| Count badge (draft) | 999px | 26px min-width | none |

- Page content column: `max-width: 1320px; margin: 0 auto; padding: 26px 24px 28px; gap: 20px` (vertical stack). Hierarchies uses `padding: 24px; gap: 18px`.
- Inside panels: horizontal padding 20px (lists) / 28px (detail areas); rows 14px vertical padding.
- No shadows on panels. Shadows only on popovers/menus, the sticky draft bar (`0 -2px 8px rgba(0,0,0,0.04)`), and toasts.
- Selected row pattern (used everywhere): `background: --nx-tint; box-shadow: inset 3px 0 0 --nx-brand;` unselected rows white.

### A4. Components (reuse exactly)

**A4.1 Primary button** — bg `--nx-brand`, text white 14px/600, pill, 38px, padding 0 20px, no border.
**A4.2 Secondary button** — white bg, 1px `--nx-control-border`, text `--nx-text` 14px/600, pill.
**A4.3 Danger text button** — transparent, no border, text `--nx-danger` 14px/600 (Reject, Discard sandbox, Withdraw).
**A4.4 Danger filled** — bg/border `--nx-danger`, white text (only the confirm step of Reject).
**A4.5 Text link** — `--nx-link`, underline, offset 2px, 13–14px.
**A4.6 Select** — `appearance: none`, 36px, 4px radius, padding `0 32px 0 10px`, 14px/600, chevron SVG 12px stroke `#5C5C5C` 2.4 absolutely positioned right 12px, `pointer-events: none`.
**A4.7 Joined toggle (segmented)** — container `display:inline-flex; border:1px solid --nx-control-border; border-radius:4px; overflow:hidden`. Segments 34px (30px in context bar, 28px small) tall, padding 0 14px, 14px/600; selected = `--nx-brand` bg + white text; unselected = white + `--nx-text`; every segment after the first has `border-left: 1px solid --nx-control-border`. `aria-pressed` on each.
**A4.8 Switch** — `role="switch" aria-checked`, track 34×20 radius 999, on `--nx-brand` / off `--nx-control-border`, knob 16×16 white, left 2px (off) / 16px (on), shadow `0 1px 2px rgba(0,0,0,.2)`; label text 14px to its right, gap 10px.
**A4.9 Tab row (in-panel)** — `role="tablist"`, row padding `0 12px`, gap 4px, bottom border 1px `--nx-border`. Tab: 46px tall (44px on Sandboxes), padding 0 10px, `border-bottom: 3px solid` (`--nx-brand` when selected, transparent otherwise), label 14px weight 700 selected / 500 not, colour `--nx-text` selected / `--nx-text-2` not; count after label 13px/400 `--nx-text-3` (red/700 when it represents blocking problems).
**A4.10 Master–detail split** — single panel (A3), internal grid `grid-template-columns: <list width> minmax(0,1fr)`, list column `border-right: 1px solid --nx-border`. List widths: Compare/Worklist 400px, Versions none (table), Sandboxes 340px, As-Was 400px (separate panels).
**A4.11 List row (button)** — full width, `display:flex; flex-direction:column; gap:3–4px; padding:14px 20px; border-bottom:1px solid --nx-divider; text-align:left`, title 15px/600, then 1–2 meta lines. Selected pattern from A3. `aria-current="true"` when selected.
**A4.12 Before/after table** — container A3; header row on `--nx-surface-2`, 13px/600 `--nx-text-2`, cell padding 10px 12–16px; body rows 14px, top border `--nx-divider` from the 2nd row; Before cell `--nx-text-3` + line-through (no strike when the before value is "—"/"New"/"Not in live"); After cell 600 on `--nx-tint`.
**A4.13 Timeline** — container `position:relative; padding-left:22px`; vertical line 2px `--nx-divider` at left 5px; each item: dot 12×12 circle, 2px white border, `box-shadow:0 0 0 1px <dot colour>`, placed at left −22px top 4–5px; text 14px/600 then meta 12px `--nx-text-3`. Dot colours: approved `--nx-brand`, comment `--nx-text-3`, other/system `--nx-muted-dot`.
**A4.14 Toast** — fixed, bottom 76px (24px on pages without draft bar), centred, bg `--nx-text`, white 14px, radius 4px, padding 10px 16px, auto-hide 2500ms, `role="status"`. Worklist toast adds an **Undo** button (30px, radius 4px, bg rgba(255,255,255,.14)).
**A4.15 Empty state** — centred in its area, title 18px/700, one line 14px `--nx-text-2`, padding 40–56px.
**A4.16 Status tag** — inline, 13px/600, 1px border, 4px radius, padding 1px 8px. Green variant: text `--nx-link`, border `--nx-tint-border`. Neutral: text `--nx-text-2`, border `--nx-control-border`. Red: text `--nx-danger`, border `--nx-danger-border`.

### A5. App shell (top of every page)

Root: `min-height:100vh; background:--nx-page; display:flex; flex-direction:column; font-family: A2`.

**A5.1 Header band** (`<header>`, bg `--nx-header-bg`, white text)
- Row 1: inner `max-width:1320px; margin:0 auto; padding:12px 24px 0; display:flex; align-items:center; gap:16px`:
  1. Logo placeholder: dashed 1.5px rgba(255,255,255,.7) box, radius 4px, padding 2px 8px, "LOGO" 12px/700 (replace with the real Fidelity logo asset).
  2. "Nexus" 24px/700.
  3. "Master Data Central" 13px rgba(255,255,255,.75).
  4. Flexible spacer.
  5. Help icon button 32×32 (question-mark-in-circle icon 20px, stroke 1.7) `aria-label="Help"`.
  6. Notifications icon button 32×32 (bell icon) with count bubble: absolute top 1px right 1px, min 15×15, radius 999, bg `--nx-notify`, text `#141414` 10px/700. `aria-label="Notifications, 3 new"`.
  7. Environment pill "Development": 12px, 1px rgba(255,255,255,.5) border, radius 999, padding 3px 12px.
  8. Vertical divider 1×22 rgba(255,255,255,.25).
  9. User button: avatar circle 30×30 rgba(255,255,255,.16) with initials 12px/700 ("VA"), then name 13px ("E2E Version Admin").
- Row 2 — main navigation `<nav aria-label="Main">`: `max-width:1320px; margin:0 auto; padding:4px 16px 0; height:42px; display:flex; gap:4px`. Each tab is an `<a>`: padding 0 12px, 14px, `border-bottom:3px solid` (`--nx-tint-border` when current, transparent otherwise), weight 700 current / 500 other, colour white current / rgba(255,255,255,.78) other, `aria-current="page"` on current.
  - Tab order: **Home · Hierarchies · Worklist [3] · Queries · Compare · As-Was · Sandboxes · Versions** (the Admin entry used in early boards is replaced by Sandboxes + Versions).
  - Worklist badge: 11px/700, text `--nx-header-bg`, bg `--nx-tint-border`, radius 999, padding 0 6px, line-height 16px. Shows the number of requests waiting for the user's decision; hidden when 0.

**A5.2 Context bar** (white, bottom border 1px `--nx-border`): inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:24px`.
1. Label "Version" 13px `--nx-text-2` + select (32px, 4px radius, 13px/600): options "2026-11 · Working", "2026-10 · Finalized". Changing it re-scopes every screen.
2. Label "Viewing as of" + date input (32px, 4px radius, 13px). Default today.
3. "Work in" + joined toggle (A4.7, 30px, 13px): **Live data** | **Sandbox**. Selected = `--nx-brand`.
4. Spacer, then link "Manage versions" (13px, `--nx-link`) → Versions screen.

**A5.3 Sticky draft bar** (all screens except Sandboxes): `position:sticky; bottom:0; background:#FFF; border-top:1px solid --nx-border; box-shadow:0 -2px 8px rgba(0,0,0,.04); z-index:20`. Inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:14px; font-size:14px`.
1. Count badge 26px pill: with drafts bg `--nx-tint-3` text `--nx-link`; empty bg `--nx-divider-soft` text `--nx-text-2`. 13px/700.
2. Text: **"Changes in your draft"** (700; singular "Change in your draft"; empty "No changes in your draft") + ` · nothing changes until approved` (`--nx-text-2`; empty: "· edits you make are collected here").
3. Spacer.
4. Link-style button "View changes" / "Hide changes" toggles a popover (`aria-expanded`).
5. Secondary 34px "Discard".
6. Primary 34px "Review and submit".
- When empty, Discard and Review and submit get `aria-disabled="true"` and `opacity:.5` (do not use the boolean `disabled` attribute binding).
- Popover: absolute, bottom calc(100% + 8px), left 24px, width 480px, radius 8px, shadow A3, padding 8px 0. Header "Changes in your draft" 13px/600 `--nx-text-2` padding 6px 16px. Each item row min-height 42px, top divider, text button 14px (clicking navigates to the node), remove × icon button 30×30 `aria-label="Remove from draft"`. Empty: "Your draft is empty." 14px `--nx-text-2`.
- Example items: "Move 34307 · AGQNT → AGCOE in ORGTL", "Edit 34301 · name “QNT Analytics Platform”".

### A6. Accessibility & behaviour baseline
- Every input has a `<label>` (visually hidden class when the design shows none: `position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)`).
- Tabs use `role="tablist"/"tab"` + `aria-selected`; segmented toggles use `aria-pressed`; switches `role="switch"` + `aria-checked`; list selection `aria-current`.
- Decorative icons/dots `aria-hidden="true"`; meaning is always also in text.
- Disabled-looking actions use `aria-disabled` + reduced opacity + a visible reason somewhere nearby.
- Text never truncates with ellipsis in lists/detail; long names wrap (`overflow-wrap:anywhere` on names/paths).
- All numbers use `en-US` grouping (2,818). Dates: "18 Nov 2026"; times 24h "10:30".

### A7. Shared demo data (use the same values on every screen)
- User: E2E Version Admin (`e2e_vadmin`, initials VA). Other people: u_editor1, u_approver1, u_admin, E2E Steward.
- Versions: **2026-11** Working (business date 18 Nov 2026, created from 2026-10), **E2E working** Working (15 Nov 2026), **2026-10** Finalized (28 Oct 2026, frozen 18 Nov 2026 06:22).
- Hierarchies: ORGTL "Total Fidelity" Primary 2,818 nodes 14 levels; ORGTP "Total Fidelity Technology" Alternate 516/12; AMBUS "Asset Management BU Alternate" Alternate 1,501/12; plus 12 alternates: E2E_H E2E Legal Group 142/8, E2E_MGMT E2E Management View 96/7, FINRPT Finance Reporting 1,210/10, LEGENT Legal Entities 388/6, GEOREG Geographic Regions 240/5, CCOWN Cost Centre Owners 2,236/9, HRORG HR Organisation 1,890/11, TAXREP Tax Reporting 610/8, OPSDEL Operations Delivery 744/9, PRODLN Product Lines 455/7, RISKV Risk View 302/6, PROJTL Project Portfolio 128/5 (15 total).
- Key nodes: ORGTL › OC005 Asset Management › AM Asset Management Executive › AMT Asset Management Technology › AMQNT Quant Technology › {AGCOE AM AI Center of Excellence, AGQNT US Quant Technology}. Leaves under AGQNT: 31679 UK QNT Tech, 34295 QNT Engineering, 34299 QNT Leadership, 34301 QNT Analytics Platform, 34322 QNT Contingent (Inactive). 34307 QNT Quant Dev (under AGCOE in ORGTL; under AGQNT in ORGTP/AMBUS).
- Draft (pending, not submitted): Move 34307 AGQNT → AGCOE in ORGTL; Rename 34301 → "QNT Analytics Platform".
- Integrity rules: CODE_UNIQUE, PARENT_EXISTS, PARENT_IS_LIMB, NO_CYCLES.


---

## Part B — Sandboxes screen

### B1. Page structure
```
[A5.1 Header] [A5.2 Context bar — "Work in" = Sandbox selected]
[B2 Sandbox strip — only while working in an owned, unsubmitted sandbox]
┌ content column (max 1320, padding 26 24 28, gap 20) ──────────────────────────────┐
│ B3 Title row: Sandboxes ................................ 2 of 5 used [New sandbox] │
│ B4 Panel: grid 340px | 1fr, min-height 700                                         │
│   ┌ list ──────────┐┌ detail ──────────────────────────────────────────────────┐ │
│   │ Your sandboxes 2││ Name (28px) [Owner]          [Discard sandbox][Open in hierarchy] │
│   │  rows           ││ Takes effect | Based on | Hierarchies (facts row)        │ │
│   │ Shared with you 1││ [3 newer changes in live data ........ Refresh from live] │ │
│   │  rows           ││ tabs: Changes 6 · Data diff 6 · Conflicts 2 · Validation 3 │
│   │                 ││ ┌ tab content ────────────────┐ ┌ readiness 300px ┐     │ │
│   │                 ││ └─────────────────────────────┘ └─────────────────┘     │ │
│   └─────────────────┘└──────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────────────────┘
```

### B2. Sandbox strip (persistent while working in a sandbox)
Shown on **every** screen (not just this one) when "Work in" = Sandbox and the active sandbox is owned by the user and not submitted. Placed directly under the context bar, full width.
- Band: bg `--nx-tint-3`, bottom border 1px `#C5D9BE`. Inner `max-width:1320px; padding:9px 24px; display:flex; align-items:center; gap:12px; flex-wrap:wrap; font-size:14px`.
  1. Label chip "SANDBOX": 12px/700 white on `--nx-link`, radius 4, padding 2px 8px.
  2. Sandbox name 14px/700.
  3. Meta `#3D3D3D`: "· 6 changes · effective 1 Dec 2026".
  4. Spacer.
  5. Button 30px pill, white bg, 1px `--nx-link` border, `--nx-link` text 13px/600: "Return to live data" — switches the context bar to Live data and hides the strip.

### B3. Title row
`display:flex; align-items:center; gap:12px 16px; flex-wrap:wrap`:
- h1 30px "Sandboxes" (flex 1). No sub line.
- 14px `--nx-text-2`: "2 of 5 used" (capacity; limit is 5 per user).
- Primary 38px "New sandbox". At 5 of 5, clicking shows the toast "You have 5 sandboxes. Discard or submit one first." (keep the button enabled so the reason is shown). Otherwise it creates a sandbox from live data (toast "New sandbox created from live data") and selects it.

### B4. List (left, 340px, `border-right`)
- Group header (`padding:12px 20px 8px; border-bottom; bg --nx-surface-2`): h2 14px/700 + count 13px `--nx-text-3`. Groups: "Your sandboxes", "Shared with you" (only if any).
- Row (A4.11 button, gap 4):
  1. name 15px/600
  2. state 13px/600, colour by state:
     - blocked: `--nx-danger` — "2 conflicts, 1 error" (parts joined by ", "; singular forms "1 conflict", "1 error")
     - ready: `--nx-link` — "Ready to submit"
     - submitted: `--nx-text-2` — "In review · CR-1049".
- Selected = A3 pattern. Selecting resets the tab to Changes.

### B5. Detail (right)
**B5.1 Head** `padding:22px 28px 0; column; gap:14px`.
- Row (`align-items:center; gap:12px; wrap`):
  - h2 28px/700 sandbox name
  - ownership tag (A4.16): "Owner" (green), "View only" (neutral), "Locked" (neutral, submitted)
  - spacer
  - "Discard sandbox" (danger text button, 36px) — owner and not submitted only. Removes the sandbox; toast `Discarded “<name>”. Live data was never changed.`
  - Secondary 36px link "Open in hierarchy" (owner) / "Open in hierarchy (read only)" (viewer or locked) → Hierarchies showing sandbox data.
- Facts row (`display:flex; gap:36px; flex-wrap:wrap; padding:14px 0; border-top:1px solid --nx-divider`), each column gap 2: label 13px `--nx-text-2`, value **20px/700**:
  - "Takes effect" — e.g. 1 Dec 2026 (the effective date; always prominent)
  - "Based on" — e.g. 2026-11 · 13 Nov
  - "Hierarchies" — e.g. ORGTL, AMBUS.

**B5.2 Live-moved-on notice** (owner only, when live data has newer committed changes in the touched hierarchies): `margin:0 28px; display:flex; align-items:center; gap:12px; padding:12px 16px; border:1px solid --nx-border; radius 8; bg --nx-surface-2; 14px`:
- text (flex 1): "3 newer changes in live data"
- secondary 32px "Refresh from live" → rebases the sandbox (keeps the user's changes; may create conflicts); toast "Refreshed from live. Your changes are kept."; the notice disappears.

**B5.3 Tabs** `role="tablist" aria-label="Sandbox sections"`, `padding:0 18px; margin-top:14px; border-bottom:1px solid --nx-border`; A4.9 with 44px tabs. Tabs and counts:
- "Changes" + number of changes
- "Data diff" + number of property rows
- "Conflicts" + number of **unresolved** conflicts — count red 700 when >0
- "Validation" + number of findings — count red 700 when there is at least one error.

**B5.4 Body** `display:grid; grid-template-columns:minmax(0,1fr) 300px; gap:24px; padding:22px 28px 28px; align-items:start`. Left = tab content (column gap 16). Right = readiness (B6).

*Changes tab* — list container A3. Row `display:grid; grid-template-columns:96px minmax(0,1fr) 80px auto; gap:12px; padding:12px 16px; align-items:start; top divider from 2nd; 14px`:
1. kind 600: Moved / Added / Renamed / Edited / Inactive
2. node: "**<name>** <code in --nx-text-3 400>" then description `--nx-text-2` (e.g. "From AGQNT to AGCOE", "Under 34295, a leaf", "Was “QNT Analytics”", "Oracle GL company 0444 → 0512", "Finance country UK → GB", "Active → Inactive")
3. hierarchy `--nx-text-3` ("ORGTL", "AMBUS", "All")
4. flag 13px/600 nowrap: "Conflict" / "Error" (`--nx-danger`), "Warning" (`--nx-text-2`), or empty.

*Data diff tab* — table A4.12 with grid `1.2fr 1fr 1fr 1fr`: header "Node", "Property", "Live", "Sandbox". Node = name 600 + code 12px `--nx-text-3`; Property `--nx-text-2`; Live struck through `--nx-text-3` (no strike for "Not in live"); Sandbox 600 on `--nx-tint`.

*Conflicts tab* — one card per conflict (gap 16 between). Card: 1px border (`--nx-danger-border` when unresolved, `--nx-border` when resolved), radius 8, overflow hidden.
- Head (`padding:12px 16px; border-bottom; gap:10px`): state tag — "Needs attention" (red variant) / "Resolved · keeping yours" / "Resolved · using live" (green); node name 15px/700; 13px `--nx-text-3` "<code> · <what>" (e.g. "34307 · parent in ORGTL").
- Two halves (`grid 1fr 1fr`, divider between), padding 12px 16px, column gap 4: label 13px `--nx-text-2` "Your sandbox" / "Live data · <who>, <date>"; value 15px/600. The chosen side gets bg `--nx-tint`.
- Footer (unresolved + owner only; `padding:10px 16px; top divider; bg --nx-surface-2`): spacer, secondary 32px "Use live value", primary 32px "Keep mine".
- No conflicts: box (1px border, radius 8, padding 20) 14px `--nx-text-2` "No conflicts with live data."

*Validation tab* — list container A3. Row `display:grid; grid-template-columns:76px minmax(0,1fr) auto; gap:12px; padding:12px 16px; align-items:start`:
1. level 700: "Error" (`--nx-danger`) / "Warning" (`--nx-text-2`)
2. title 600 + one short line `--nx-text-2` (e.g. "Parent 34295 is a leaf")
3. link 13px "Fix in tree" → Hierarchies at the node.
Errors block submission; warnings do not. Conflicts are never listed here (separate concept).

### B6. Readiness box (right, 300px, `position:sticky; top:16px`)
Card: 1px border, radius 8, padding 18, column gap 12, white.
- Title 18px/700.
- Check lines (column gap 8), each `display:flex; align-items:baseline; gap:10px; 14px`: mark (14px wide, 700) + text.
  - ✓ `--nx-brand` + text `--nx-text`; ✕ `--nx-danger` + text `--nx-danger` 600; ! `--nx-text-2` + text `--nx-text`.
- Full-width 40px pill button.

| State | Border / title colour | Title | Lines | Button |
|---|---|---|---|---|
| Owner, blocked | `--nx-danger-border` / `--nx-danger` | "Not ready" | ✓ 6 changes · ✕ 2 conflicts · ✕ 1 error · ! 2 warnings | secondary "Review issues" → opens Conflicts tab if any unresolved, else Validation |
| Owner, ready | `--nx-tint-border` / `--nx-link` | "Ready to submit" | ✓ 3 changes · ✓ No conflicts · ✓ No errors · ! 1 warning | primary "Submit as request" → toast "Submitted as CR-1051. Live data changes only after approval." |
| Viewer | `--nx-border` / `--nx-text` | "View only" | ✓ Owner: E2E Steward | secondary "Copy to mine" → toast "Copied to your sandboxes" |
| Submitted | `--nx-border` / `--nx-text` | "In review" | ✓ 12 changes · ✓ With u_approver1 | secondary "Open CR-1049" → Worklist |

Line texts: "<n> changes"; "No conflicts" or "<n> conflict(s)"; "No errors" or "<n> error(s)"; "<n> warning(s)" only when >0.

### B7. Demo data
**sb1 — AGCOE reorganisation** (yours, owner). Takes effect 1 Dec 2026 · Based on 2026-11 · 13 Nov · ORGTL, AMBUS · 3 newer changes in live data.
- Changes: Moved 34307 QNT Quant Dev "From AGQNT to AGCOE" ORGTL **Conflict**; Moved 34295 QNT Engineering "From AGQNT to AGCOE" ORGTL; Added 99310 AI Platform Ops "Under 34295, a leaf" ORGTL **Error**; Renamed 34301 QNT Analytics Platform "Was “QNT Analytics”" All **Conflict**; Edited 34295 QNT Engineering "Oracle GL company 0444 → 0512" ORGTL; Edited 31679 UK QNT Tech "Finance country UK → GB" AMBUS **Warning**.
- Data diff: 34307 Parent in ORGTL AGQNT→AGCOE; 34295 Parent in ORGTL AGQNT→AGCOE; 34295 Oracle GL company 0444→0512; 34301 Name QNT Analytics→QNT Analytics Platform; 99310 Node "Not in live"→"New leaf under 34295"; 31679 Finance country UK→GB.
- Conflicts: 34307 QNT Quant Dev · parent in ORGTL — yours "Under AGCOE", live "Under AMFIT" (u_editor1, 18 Nov). 34301 QNT Analytics · name — yours "QNT Analytics Platform", live "QNT Analytics Hub" (E2E Steward, 17 Nov).
- Validation: Error "AI Platform Ops is under a leaf" — "Parent 34295 is a leaf" (rule PARENT_IS_LIMB); Warning "Unusual finance country" — "31679 uses “GB”, others use “UK”"; Warning "Renaming an inactive node" — "34301 is inactive".

**sb2 — AMBUS quarterly review** (yours). 1 Jan 2027 · 2026-11 · 18 Nov · AMBUS. Changes: Inactive 41640 UK Legacy Ops "Active → Inactive"; Inactive 34322 QNT Contingent "Active → Inactive"; Renamed 41210 Equity Research Tools "Was “Equity Research Tooling”" All Warning. No conflicts. Validation: Warning "Rename applies everywhere" — "Shows in 4 hierarchies". → Ready to submit.

**sb3 — Finance country clean-up** (shared with you, owner E2E Steward, submitted CR-1049). 1 Dec 2026 · 2026-11 · 10 Nov · ORGTL, ORGTP. 3 shown property edits (Finance country UK → GB on 31679, 41210, 41640). Read only.

### B8. Behaviour
- Working in a sandbox: all screens read sandbox data; edits go into the sandbox, not the draft bar.
- A viewer can open everything read only; no Discard, no conflict buttons, no submit.
- Submitting locks the sandbox (tag "Locked") until the request is approved, sent back (unlocks) or rejected.
- Refresh/concurrency failures show as the B5.2 notice style with "Try again", never as a blocking error page.

### B9. Acceptance checklist
- [ ] Strip under the context bar shows name, changes, effective date and Return to live data.
- [ ] Title row has only the title, capacity and New sandbox.
- [ ] No explanatory paragraphs in tabs.
- [ ] Conflicts and validation in separate tabs; red counts when blocking.
- [ ] Readiness box always visible and says why submit is unavailable.
- [ ] Owner / View only / Locked tag next to the name.
