# Nexus – Home screen · UI specification

**Route:** `/` (or `/home`) · **Header tab:** Home (current) · **Mockup board:** "Home (Nexus title · calmer palette)" — `Home-G.dc.html`
**Purpose:** the landing page. Answers three questions in this order: *what needs me now*, *where do I go*, *what happened recently*. It is not a dashboard of KPIs and it does not repeat the main navigation.

How to use this document: build Part A (shared shell, tokens, components) once; then build Part B exactly. Every string in quotes is final copy. Every number is a design value, not an example, unless marked "(data)".


---

## Part A — Shared foundations (identical on every Nexus screen)

> This part is the same in all 8 screen specs. Do not change any value here for one screen only. If a value here conflicts with something in Part B, Part A wins unless Part B says it overrides it.

### A1. Design tokens

Use these exact values. Do not add new colours, shades, shadows or radii.

| Token | Value | Use |
|---|---|---|
| `--nx-header-bg` | `#044014` | Top header band only. Never used for buttons or highlights in the page body. |
| `--nx-brand` | `#368727` | Every filled primary button, active tab underline in the page body, selected toggle segment, switch "on", checkbox fill, selected day bar, timeline dot "approved", selected-row left edge. White text on it (contrast 4.5:1). |
| `--nx-link` | `#2B6A1F` | All text links (underlined, `text-underline-offset: 2px`), green tag text, positive status text. |
| `--nx-link-hover` | `#1E4F15` | Link hover. |
| `--nx-tint` | `#F3F6F1` | Selected row background, "new value" cell background, current-step background. |
| `--nx-tint-2` | `#E6EFE2` | Selected option background in dropdown lists, hierarchy icon tile. |
| `--nx-tint-3` | `#E8F1E5` | Draft-count badge background; sandbox strip background. |
| `--nx-tint-border` | `#A8CF9C` | Border of green outlined tags; header active-tab underline; header badge background. |
| `--nx-tint-border-2` | `#DCE6D8` / `#C5D9BE` | Border of pale-green boxes (draft callout, sandbox strip). |
| `--nx-page` | `#F9F7F5` | Page background under everything below the header. |
| `--nx-surface` | `#FFFFFF` | Panels, inputs, menus. |
| `--nx-surface-2` | `#FCFBFA` | Table header rows, group header rows, inset boxes, separator rows. |
| `--nx-border` | `#E5E1DC` | Panel borders, table borders, tab-row bottom border. |
| `--nx-divider` | `#EEEAE5` | Row dividers inside panels, section dividers. |
| `--nx-divider-soft` | `#F1EEEA` | Very light row dividers (property rows), neutral chip background. |
| `--nx-control-border` | `#C9C4BE` | Input/select/outline-button borders, unselected switch track. |
| `--nx-text` | `#141414` | Primary text. |
| `--nx-text-2` | `#5C5C5C` | Secondary text, field labels, meta lines. |
| `--nx-text-3` | `#8A8580` | Tertiary text: codes under names, counts in tabs, timestamps, placeholders for empty values. |
| `--nx-muted-dot` | `#B5AFA8` | Neutral timeline dots, leaf dots. |
| `--nx-danger` | `#B42318` | Only: overdue, errors, conflicts, Reject / Delete / Discard-sandbox actions. Never decorative. |
| `--nx-danger-border` | `#E8B4AE` | Border of a red outlined tag / blocked card. |
| `--nx-notify` | `#F2B33D` | Only the notification-count bubble in the header. |

**Colour rules (hard):**
1. One accent: green. No blue, purple or amber anywhere in the page body.
2. A change type (added, moved, renamed …) is shown with **words**, never a colour per type.
3. Red appears only when something is wrong or destructive.
4. Old value = `--nx-text-3` + `line-through`. New value = `font-weight: 600` on `--nx-tint`.

### A2. Typography

- Font stack: `'Fidelity Sans', 'Hind', Helvetica, Arial, sans-serif`. Load Hind 400/500/600/700 from Google Fonts as the fallback; if the app already ships Fidelity Sans (as the Fidelity Shares app does), use it.
- No monospace font anywhere (codes use the normal font).
- Base text colour `--nx-text`.

| Role | Size / weight | Notes |
|---|---|---|
| Page title (h1) | 30px / 700, letter-spacing −0.01em | One per page. Exception: Hierarchies uses 28px. |
| Detail title (h2 inside a panel) | 28px / 700, line-height 1.25 | Selected item's name. Hierarchies node name 30px. |
| Section title (h3) | 16px / 700 | "Request details", "What changed" … sentence case. |
| Panel heading (h2 in a list panel) | 18px / 700 | "Needs your attention", "Recent activity" … |
| Group header in a list | 14px / 700 + count 13px `--nx-text-3` | On `--nx-surface-2` background. |
| Body | 14–15px / 400 | Row titles 15px / 600. |
| Field label | 13px / 600 `--nx-text-2`, sentence case | "Hierarchy", "From version" … Never ALL CAPS. |
| Meta line | 13px / 400 `--nx-text-2` or `--nx-text-3` | |
| Tiny caps label | 12px / 700, letter-spacing 0.08em, `--nx-text-3` | Only allowed on Home snapshot labels, Hierarchies "WHERE IT LIVES"/property category headers, dropdown group headers (PRIMARY / ALTERNATES, Finance/HR column groups). Nowhere else. |
| Big fact value | 18–20px / 700 | Facts rows (Sandboxes, Versions). |

Copy rules: sentence case; no exclamation marks; no "AI-style" helper sentences under titles. A line under a page title is allowed only when it states live state (e.g. "3 requests need your decision · 1 overdue"). Use `·` (middle dot with spaces) to join short facts.

### A3. Shape, spacing, elevation

| Element | Radius | Height | Border |
|---|---|---|---|
| Panel / card / table container | 8px | — | 1px `--nx-border` |
| Input, select, date, textarea, joined toggle group, square icon button | 4px | 36px (38px for page-level search) | 1px `--nx-control-border` |
| Button (filled or outline) | 999px (pill) | 38px default, 34px in bars, 32px in rows/cards | outline = 1px `--nx-control-border`, white bg |
| Small tag (status/ownership) | 4px | auto, padding 1px 8px, 13px/600 | 1px tint-border |
| Menu / popover | 6–8px | — | 1px `--nx-border` or `--nx-control-border`, shadow `0 8px 24px rgba(0,0,0,0.10)` |
| Count badge (draft) | 999px | 26px min-width | none |

- Page content column: `max-width: 1320px; margin: 0 auto; padding: 26px 24px 28px; gap: 20px` (vertical stack). Hierarchies uses `padding: 24px; gap: 18px`.
- Inside panels: horizontal padding 20px (lists) / 28px (detail areas); rows 14px vertical padding.
- No shadows on panels. Shadows only on popovers/menus, the sticky draft bar (`0 -2px 8px rgba(0,0,0,0.04)`), and toasts.
- Selected row pattern (used everywhere): `background: --nx-tint; box-shadow: inset 3px 0 0 --nx-brand;` unselected rows white.

### A4. Components (reuse exactly)

**A4.1 Primary button** — bg `--nx-brand`, text white 14px/600, pill, 38px, padding 0 20px, no border.
**A4.2 Secondary button** — white bg, 1px `--nx-control-border`, text `--nx-text` 14px/600, pill.
**A4.3 Danger text button** — transparent, no border, text `--nx-danger` 14px/600 (Reject, Discard sandbox, Withdraw).
**A4.4 Danger filled** — bg/border `--nx-danger`, white text (only the confirm step of Reject).
**A4.5 Text link** — `--nx-link`, underline, offset 2px, 13–14px.
**A4.6 Select** — `appearance: none`, 36px, 4px radius, padding `0 32px 0 10px`, 14px/600, chevron SVG 12px stroke `#5C5C5C` 2.4 absolutely positioned right 12px, `pointer-events: none`.
**A4.7 Joined toggle (segmented)** — container `display:inline-flex; border:1px solid --nx-control-border; border-radius:4px; overflow:hidden`. Segments 34px (30px in context bar, 28px small) tall, padding 0 14px, 14px/600; selected = `--nx-brand` bg + white text; unselected = white + `--nx-text`; every segment after the first has `border-left: 1px solid --nx-control-border`. `aria-pressed` on each.
**A4.8 Switch** — `role="switch" aria-checked`, track 34×20 radius 999, on `--nx-brand` / off `--nx-control-border`, knob 16×16 white, left 2px (off) / 16px (on), shadow `0 1px 2px rgba(0,0,0,.2)`; label text 14px to its right, gap 10px.
**A4.9 Tab row (in-panel)** — `role="tablist"`, row padding `0 12px`, gap 4px, bottom border 1px `--nx-border`. Tab: 46px tall (44px on Sandboxes), padding 0 10px, `border-bottom: 3px solid` (`--nx-brand` when selected, transparent otherwise), label 14px weight 700 selected / 500 not, colour `--nx-text` selected / `--nx-text-2` not; count after label 13px/400 `--nx-text-3` (red/700 when it represents blocking problems).
**A4.10 Master–detail split** — single panel (A3), internal grid `grid-template-columns: <list width> minmax(0,1fr)`, list column `border-right: 1px solid --nx-border`. List widths: Compare/Worklist 400px, Versions none (table), Sandboxes 340px, As-Was 400px (separate panels).
**A4.11 List row (button)** — full width, `display:flex; flex-direction:column; gap:3–4px; padding:14px 20px; border-bottom:1px solid --nx-divider; text-align:left`, title 15px/600, then 1–2 meta lines. Selected pattern from A3. `aria-current="true"` when selected.
**A4.12 Before/after table** — container A3; header row on `--nx-surface-2`, 13px/600 `--nx-text-2`, cell padding 10px 12–16px; body rows 14px, top border `--nx-divider` from the 2nd row; Before cell `--nx-text-3` + line-through (no strike when the before value is "—"/"New"/"Not in live"); After cell 600 on `--nx-tint`.
**A4.13 Timeline** — container `position:relative; padding-left:22px`; vertical line 2px `--nx-divider` at left 5px; each item: dot 12×12 circle, 2px white border, `box-shadow:0 0 0 1px <dot colour>`, placed at left −22px top 4–5px; text 14px/600 then meta 12px `--nx-text-3`. Dot colours: approved `--nx-brand`, comment `--nx-text-3`, other/system `--nx-muted-dot`.
**A4.14 Toast** — fixed, bottom 76px (24px on pages without draft bar), centred, bg `--nx-text`, white 14px, radius 4px, padding 10px 16px, auto-hide 2500ms, `role="status"`. Worklist toast adds an **Undo** button (30px, radius 4px, bg rgba(255,255,255,.14)).
**A4.15 Empty state** — centred in its area, title 18px/700, one line 14px `--nx-text-2`, padding 40–56px.
**A4.16 Status tag** — inline, 13px/600, 1px border, 4px radius, padding 1px 8px. Green variant: text `--nx-link`, border `--nx-tint-border`. Neutral: text `--nx-text-2`, border `--nx-control-border`. Red: text `--nx-danger`, border `--nx-danger-border`.

### A5. App shell (top of every page)

Root: `min-height:100vh; background:--nx-page; display:flex; flex-direction:column; font-family: A2`.

**A5.1 Header band** (`<header>`, bg `--nx-header-bg`, white text)
- Row 1: inner `max-width:1320px; margin:0 auto; padding:12px 24px 0; display:flex; align-items:center; gap:16px`:
  1. Logo placeholder: dashed 1.5px rgba(255,255,255,.7) box, radius 4px, padding 2px 8px, "LOGO" 12px/700 (replace with the real Fidelity logo asset).
  2. "Nexus" 24px/700.
  3. "Master Data Central" 13px rgba(255,255,255,.75).
  4. Flexible spacer.
  5. Help icon button 32×32 (question-mark-in-circle icon 20px, stroke 1.7) `aria-label="Help"`.
  6. Notifications icon button 32×32 (bell icon) with count bubble: absolute top 1px right 1px, min 15×15, radius 999, bg `--nx-notify`, text `#141414` 10px/700. `aria-label="Notifications, 3 new"`.
  7. Environment pill "Development": 12px, 1px rgba(255,255,255,.5) border, radius 999, padding 3px 12px.
  8. Vertical divider 1×22 rgba(255,255,255,.25).
  9. User button: avatar circle 30×30 rgba(255,255,255,.16) with initials 12px/700 ("VA"), then name 13px ("E2E Version Admin").
- Row 2 — main navigation `<nav aria-label="Main">`: `max-width:1320px; margin:0 auto; padding:4px 16px 0; height:42px; display:flex; gap:4px`. Each tab is an `<a>`: padding 0 12px, 14px, `border-bottom:3px solid` (`--nx-tint-border` when current, transparent otherwise), weight 700 current / 500 other, colour white current / rgba(255,255,255,.78) other, `aria-current="page"` on current.
  - Tab order: **Home · Hierarchies · Worklist [3] · Queries · Compare · As-Was · Sandboxes · Versions** (the Admin entry used in early boards is replaced by Sandboxes + Versions).
  - Worklist badge: 11px/700, text `--nx-header-bg`, bg `--nx-tint-border`, radius 999, padding 0 6px, line-height 16px. Shows the number of requests waiting for the user's decision; hidden when 0.

**A5.2 Context bar** (white, bottom border 1px `--nx-border`): inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:24px`.
1. Label "Version" 13px `--nx-text-2` + select (32px, 4px radius, 13px/600): options "2026-11 · Working", "2026-10 · Finalized". Changing it re-scopes every screen.
2. Label "Viewing as of" + date input (32px, 4px radius, 13px). Default today.
3. "Work in" + joined toggle (A4.7, 30px, 13px): **Live data** | **Sandbox**. Selected = `--nx-brand`.
4. Spacer, then link "Manage versions" (13px, `--nx-link`) → Versions screen.

**A5.3 Sticky draft bar** (all screens except Sandboxes): `position:sticky; bottom:0; background:#FFF; border-top:1px solid --nx-border; box-shadow:0 -2px 8px rgba(0,0,0,.04); z-index:20`. Inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:14px; font-size:14px`.
1. Count badge 26px pill: with drafts bg `--nx-tint-3` text `--nx-link`; empty bg `--nx-divider-soft` text `--nx-text-2`. 13px/700.
2. Text: **"Changes in your draft"** (700; singular "Change in your draft"; empty "No changes in your draft") + ` · nothing changes until approved` (`--nx-text-2`; empty: "· edits you make are collected here").
3. Spacer.
4. Link-style button "View changes" / "Hide changes" toggles a popover (`aria-expanded`).
5. Secondary 34px "Discard".
6. Primary 34px "Review and submit".
- When empty, Discard and Review and submit get `aria-disabled="true"` and `opacity:.5` (do not use the boolean `disabled` attribute binding).
- Popover: absolute, bottom calc(100% + 8px), left 24px, width 480px, radius 8px, shadow A3, padding 8px 0. Header "Changes in your draft" 13px/600 `--nx-text-2` padding 6px 16px. Each item row min-height 42px, top divider, text button 14px (clicking navigates to the node), remove × icon button 30×30 `aria-label="Remove from draft"`. Empty: "Your draft is empty." 14px `--nx-text-2`.
- Example items: "Move 34307 · AGQNT → AGCOE in ORGTL", "Edit 34301 · name “QNT Analytics Platform”".

### A6. Accessibility & behaviour baseline
- Every input has a `<label>` (visually hidden class when the design shows none: `position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)`).
- Tabs use `role="tablist"/"tab"` + `aria-selected`; segmented toggles use `aria-pressed`; switches `role="switch"` + `aria-checked`; list selection `aria-current`.
- Decorative icons/dots `aria-hidden="true"`; meaning is always also in text.
- Disabled-looking actions use `aria-disabled` + reduced opacity + a visible reason somewhere nearby.
- Text never truncates with ellipsis in lists/detail; long names wrap (`overflow-wrap:anywhere` on names/paths).
- All numbers use `en-US` grouping (2,818). Dates: "18 Nov 2026"; times 24h "10:30".

### A7. Shared demo data (use the same values on every screen)
- User: E2E Version Admin (`e2e_vadmin`, initials VA). Other people: u_editor1, u_approver1, u_admin, E2E Steward.
- Versions: **2026-11** Working (business date 18 Nov 2026, created from 2026-10), **E2E working** Working (15 Nov 2026), **2026-10** Finalized (28 Oct 2026, frozen 18 Nov 2026 06:22).
- Hierarchies: ORGTL "Total Fidelity" Primary 2,818 nodes 14 levels; ORGTP "Total Fidelity Technology" Alternate 516/12; AMBUS "Asset Management BU Alternate" Alternate 1,501/12; plus 12 alternates: E2E_H E2E Legal Group 142/8, E2E_MGMT E2E Management View 96/7, FINRPT Finance Reporting 1,210/10, LEGENT Legal Entities 388/6, GEOREG Geographic Regions 240/5, CCOWN Cost Centre Owners 2,236/9, HRORG HR Organisation 1,890/11, TAXREP Tax Reporting 610/8, OPSDEL Operations Delivery 744/9, PRODLN Product Lines 455/7, RISKV Risk View 302/6, PROJTL Project Portfolio 128/5 (15 total).
- Key nodes: ORGTL › OC005 Asset Management › AM Asset Management Executive › AMT Asset Management Technology › AMQNT Quant Technology › {AGCOE AM AI Center of Excellence, AGQNT US Quant Technology}. Leaves under AGQNT: 31679 UK QNT Tech, 34295 QNT Engineering, 34299 QNT Leadership, 34301 QNT Analytics Platform, 34322 QNT Contingent (Inactive). 34307 QNT Quant Dev (under AGCOE in ORGTL; under AGQNT in ORGTP/AMBUS).
- Draft (pending, not submitted): Move 34307 AGQNT → AGCOE in ORGTL; Rename 34301 → "QNT Analytics Platform".
- Integrity rules: CODE_UNIQUE, PARENT_EXISTS, PARENT_IS_LIMB, NO_CYCLES.


---

## Part B — Home screen

### B1. Page structure (top to bottom)

```
[A5.1 Header]  [A5.2 Context bar]
┌ content column (max 1320, padding 26 24 32, gap 22) ─────────────────────────┐
│ B2 Title row ......................................... [Create sandbox][Raise a request] │
│ B3 Search (52px)                                                    [Search] │
│ B4 Snapshot strip (4 equal cells)                                            │
│ B5 Two columns  1.55fr | 1fr  (gap 20, align-items:start)                    │
│   left:  B6 Needs your attention   right: B8 Recent activity                 │
│          B7 Hierarchies                   B9 Learn Nexus                     │
└──────────────────────────────────────────────────────────────────────────────┘
[A5.3 Sticky draft bar]
```
Content column for Home only: `padding: 26px 24px 32px; gap: 22px`.

### B2. Title row
- Container: `display:flex; align-items:flex-end; gap:16px; flex-wrap:wrap`.
- Left block (`flex:1 1 auto; flex-direction:column; gap:6px`):
  - h1, 30px/700, −0.01em, `--nx-text`: **"Nexus – Master Data Central"**. The en dash "–" is rendered 400 weight in `--nx-text-3`; "Nexus" and "Master Data Central" are 700.
  - Status line 15px `--nx-text-2`: "Version **2026-11** is open for changes until 30 Nov" — the version code is 600 `--nx-text`. (data: version code and close date come from the selected working version; if the selected version is Finalized show "Version 2026-10 is finalized and read only".)
- Right: two buttons, bottom-aligned with the title:
  1. Secondary pill 38px, padding 0 16px: **"Create sandbox"** → opens the New sandbox flow (Sandboxes screen).
  2. Primary pill 38px, padding 0 20px: **"Raise a request"** → Hierarchies screen (start a change).
- No greeting ("Good afternoon") and no date line.

### B3. Global search
- Wrapper `position:relative`.
- Hidden label "Find a node or request".
- Search icon: 20×20, stroke `#5C5C5C` 2, absolute left 18px top 16px, `aria-hidden`.
- Input `type="search"`: full width, height **52px**, radius **8px**, border 1px `--nx-control-border`, padding `0 130px 0 50px`, 16px, white, `box-shadow: 0 1px 2px rgba(0,0,0,.04)`.
- Placeholder: "Find a node by code or name, or a request like CR-1041".
- Inline button inside the input on the right: absolute right 7px top 7px, primary pill 38px, padding 0 22px: **"Search"**.
- Behaviour: Enter or Search runs the search. A node code/name opens Hierarchies with that node selected; a request number pattern `CR-\d+` opens Worklist with that request selected. Fewer than 2 characters does nothing.

### B4. Snapshot strip
- `<section aria-label="Snapshot">`, panel (white, 1px `--nx-border`, radius 8, overflow hidden), `display:grid; grid-template-columns:repeat(4,minmax(0,1fr))`.
- Each cell is an `<a>` (whole cell clickable): `display:flex; flex-direction:column; gap:4px; padding:16px 20px; color:--nx-text; text-decoration:none`. Cells 2–4 have `border-left:1px solid --nx-divider` (first cell none).
- Cell content:
  1. Label: tiny caps (12px/700, 0.08em, `--nx-text-3`).
  2. Number row (`display:flex; align-items:baseline; gap:8px`): number 30px/700 line-height 1.1 `--nx-text`; unit 14px `--nx-text-2`.
  3. Detail 13px `--nx-text-2`.
- The four cells (data):

| Label | Number | Unit | Detail | Link target |
|---|---|---|---|---|
| WAITING FOR YOU | 3 | requests | 1 overdue | Worklist, tab "To decide" |
| YOUR REQUESTS | 2 | open | 1 in review · 1 sent back | Worklist, tab "My requests" |
| IN YOUR DRAFT | 2 | changes | Not submitted yet | Hierarchies (draft list) |
| CHANGES THIS MONTH | 24 | committed | 18 nodes · 6 requests | As-Was |

- All numbers are `--nx-text` (no coloured numbers). No icons, no trend arrows, no percentages.

### B5. Two-column area
`display:grid; grid-template-columns:minmax(0,1.55fr) minmax(0,1fr); gap:20px; align-items:start`. Each column is `flex-direction:column; gap:20px; min-width:0`.

### B6. Needs your attention (left, first)
- Panel `<section aria-label="Needs your attention">`, overflow hidden.
- Header row: `display:flex; align-items:baseline; gap:10px; padding:16px 20px 10px`:
  - h2 18px/700 "Needs your attention"
  - count 13px `--nx-text-2`: "4 items"
  - spacer
  - link 13px "Open worklist" → Worklist.
- Rows (one per item): `display:flex; align-items:center; gap:14px; padding:12px 20px; border-top:1px solid --nx-divider`.
  - Text block (`flex:1; min-width:0; column; gap:2px`): title 15px/600; meta 13px `--nx-text-2` = "<request id> · <from …>" + " · " + due text.
  - Due text styling: overdue → `--nx-danger` 700; due soon → `--nx-text` 600; later → `--nx-text-2` 400; sent back → `--nx-text` 600.
  - Action at the right: 32px pill, padding 0 14px, 13px/600, `white-space:nowrap`. **Only the most urgent row (overdue) uses the primary style; every other row uses the secondary style.**
  - No coloured urgency dots.
- Rows (data, sorted overdue → soon → later → sent back):

| Title | Meta | Due | Action |
|---|---|---|---|
| Update GL company for 41408 | CR-1041 · from u_editor1 | Overdue by 1 day (red) | Review (primary) |
| Move 3 cost centres from AMFIT to AMEQT | CR-1046 · from E2E Steward | Due in 2 days | Review |
| Add 2 cost centres under AGCOE | CR-1048 · from E2E Steward | Due in 4 days | Review |
| Rename AGCOE to “AM AI Centre of Excellence” | CR-1044 · your request | Sent back with a note | Open |

- Review/Open → Worklist with that request selected.
- Empty state: one row text 14px `--nx-text-2` "Nothing needs you right now." (no button).
- Show max 5 rows; if more, the header count shows the total and "Open worklist" is the way to see all.

### B7. Hierarchies (left, second)
- Header row same pattern as B6: h2 "Hierarchies"; sub 13px `--nx-text-2` "Most used · 15 in total"; link "View all 15" → Hierarchies.
- Rows are `<a>` → Hierarchies with that hierarchy selected. `display:grid; grid-template-columns:84px minmax(0,1fr) 110px 120px 16px; align-items:center; gap:12px; padding:11px 20px; border-top:1px solid --nx-divider; color:--nx-text`.
  1. Code 13px/700.
  2. Name block: name 14px/600; under it 12px `--nx-text-3` "<Primary|Alternate> · <n> nodes".
  3. Open requests 13px: "2 open" (`--nx-text` 600) or "No requests" (`--nx-text-3` 400).
  4. Last change 13px `--nx-text-2`: "Changed 17 Nov".
  5. Chevron-right icon 14px stroke `--nx-text-3` (`aria-hidden`).
- Rows (data): ORGTL Total Fidelity · Primary · 2,818 · 2 open · Changed 17 Nov / ORGTP Total Fidelity Technology · Alternate · 516 · No requests · Changed 13 Nov / AMBUS Asset Management BU Alternate · Alternate · 1,501 · 1 open · Changed 4 Nov / CCOWN Cost Centre Owners · Alternate · 2,236 · 1 open · Changed 12 Nov / FINRPT Finance Reporting · Alternate · 1,210 · No requests · Changed 9 Nov.
- Always 5 rows: the user's 5 most-used hierarchies (by visits in the last 30 days; fall back to Primary first then by node count). No percentages, no progress bars, no charts.

### B8. Recent activity (right, first)
- Header: `padding:16px 20px 6px`; h2 "Recent activity"; spacer; link "View all" → As-Was.
- Body: timeline (A4.13) with container `position:relative; padding:12px 20px 4px 42px`, vertical line at left 25px, top 18px, bottom 22px.
- Item: text 14px/600 line-height 1.4; meta 12px `--nx-text-3` margin-top 2px "<when> · <who>".
- Items (data, newest first, max 5):

| Dot | Text | Meta |
|---|---|---|
| green | CR-1047 approved — AI Platform Ops added under AGCOE | Yesterday, 3:30 PM · u_approver1 |
| grey | Your request CR-1044 was sent back | 15 Nov, 5:02 PM · u_approver1 |
| green | CR-1038 approved — 4 changes in ORGTL | 13 Nov, 10:52 AM · u_approver1 |
| grey | AMBUS review sandbox created | 12 Nov, 4:30 PM · E2E Steward |
| grey | Version 2026-11 opened from 2026-10 | 1 Nov, 9:00 AM · system |

Green = `--nx-brand` (approved/committed); grey = `--nx-muted-dot` (everything else). No amber.

### B9. Learn Nexus (right, second)
- Panel `padding:16px 20px; display:flex; flex-direction:column; gap:10px`.
- Header: tiny caps "LEARN NEXUS".
- Four link rows `<a>`: `display:flex; align-items:baseline; gap:10px`; title 14px/600 `--nx-text` (no underline, flex 1); meta 12px `--nx-text-3` nowrap.
- Rows: "How versions work" — "Guide · 2 min"; "Finding your way in a hierarchy" — "Guide · 3 min"; "From draft to approval" — "Video · 2 min"; "Trying changes in a sandbox" — "Guide · 3 min".
- No images or cards.

### B10. Draft bar
A5.3 with 2 items (data): "Move 34307 · AGQNT → AGCOE in ORGTL", "Edit 34301 · name “QNT Analytics Platform”".

### B11. States & responsive
- Loading: each panel shows 3–4 grey skeleton lines (`--nx-divider-soft`, radius 4) in the row positions; the title row and search render immediately.
- Error in one panel: replace its rows with 14px `--nx-text-2` "Couldn’t load this. " + link "Try again". Other panels unaffected.
- Below 1100px width: the two columns stack (left column first). Snapshot becomes 2×2 grid.
- Nothing on Home is editable; it only links.

### B12. What NOT to build on Home
No greeting, no big banner, no KPI tiles with icons, no percentage/completion rings, no list of links to other screens (the header tabs already do that), no colour per status.

### B13. Acceptance checklist
- [ ] Title reads exactly "Nexus – Master Data Central".
- [ ] Only one primary button visible in the title row and one in the attention list.
- [ ] Snapshot numbers all black; whole cells clickable.
- [ ] Only red used is "Overdue by 1 day".
- [ ] Hierarchy rows show code, name, type · nodes, open count, last change, chevron.
- [ ] Draft bar present and identical to other screens.
