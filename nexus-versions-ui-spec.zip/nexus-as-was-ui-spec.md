# Nexus – As-Was screen · UI specification

**Route:** `/as-was?h=<hier>&t=<yyyy-mm-ddThh:mm>` · **Header tab:** As-Was · **Mockup board:** "As-Was (redesign · new Home style)" — `AsWas-C.dc.html`
**Purpose:** show a hierarchy exactly as it was at a chosen moment (approved changes only), let the user step through the day's changes, and optionally preview what changed afterwards.


---

## Part A — Shared foundations (identical on every Nexus screen)

> This part is the same in all 8 screen specs. Do not change any value here for one screen only. If a value here conflicts with something in Part B, Part A wins unless Part B says it overrides it.

### A1. Design tokens

Use these exact values. Do not add new colours, shades, shadows or radii.

| Token | Value | Use |
|---|---|---|
| `--nx-header-bg` | `#044014` | Top header band only. Never used for buttons or highlights in the page body. |
| `--nx-brand` | `#368727` | Every filled primary button, active tab underline in the page body, selected toggle segment, switch "on", checkbox fill, selected day bar, timeline dot "approved", selected-row left edge. White text on it (contrast 4.5:1). |
| `--nx-link` | `#2B6A1F` | All text links (underlined, `text-underline-offset: 2px`), green tag text, positive status text. |
| `--nx-link-hover` | `#1E4F15` | Link hover. |
| `--nx-tint` | `#F3F6F1` | Selected row background, "new value" cell background, current-step background. |
| `--nx-tint-2` | `#E6EFE2` | Selected option background in dropdown lists, hierarchy icon tile. |
| `--nx-tint-3` | `#E8F1E5` | Draft-count badge background; sandbox strip background. |
| `--nx-tint-border` | `#A8CF9C` | Border of green outlined tags; header active-tab underline; header badge background. |
| `--nx-tint-border-2` | `#DCE6D8` / `#C5D9BE` | Border of pale-green boxes (draft callout, sandbox strip). |
| `--nx-page` | `#F9F7F5` | Page background under everything below the header. |
| `--nx-surface` | `#FFFFFF` | Panels, inputs, menus. |
| `--nx-surface-2` | `#FCFBFA` | Table header rows, group header rows, inset boxes, separator rows. |
| `--nx-border` | `#E5E1DC` | Panel borders, table borders, tab-row bottom border. |
| `--nx-divider` | `#EEEAE5` | Row dividers inside panels, section dividers. |
| `--nx-divider-soft` | `#F1EEEA` | Very light row dividers (property rows), neutral chip background. |
| `--nx-control-border` | `#C9C4BE` | Input/select/outline-button borders, unselected switch track. |
| `--nx-text` | `#141414` | Primary text. |
| `--nx-text-2` | `#5C5C5C` | Secondary text, field labels, meta lines. |
| `--nx-text-3` | `#8A8580` | Tertiary text: codes under names, counts in tabs, timestamps, placeholders for empty values. |
| `--nx-muted-dot` | `#B5AFA8` | Neutral timeline dots, leaf dots. |
| `--nx-danger` | `#B42318` | Only: overdue, errors, conflicts, Reject / Delete / Discard-sandbox actions. Never decorative. |
| `--nx-danger-border` | `#E8B4AE` | Border of a red outlined tag / blocked card. |
| `--nx-notify` | `#F2B33D` | Only the notification-count bubble in the header. |

**Colour rules (hard):**
1. One accent: green. No blue, purple or amber anywhere in the page body.
2. A change type (added, moved, renamed …) is shown with **words**, never a colour per type.
3. Red appears only when something is wrong or destructive.
4. Old value = `--nx-text-3` + `line-through`. New value = `font-weight: 600` on `--nx-tint`.

### A2. Typography

- Font stack: `'Fidelity Sans', 'Hind', Helvetica, Arial, sans-serif`. Load Hind 400/500/600/700 from Google Fonts as the fallback; if the app already ships Fidelity Sans (as the Fidelity Shares app does), use it.
- No monospace font anywhere (codes use the normal font).
- Base text colour `--nx-text`.

| Role | Size / weight | Notes |
|---|---|---|
| Page title (h1) | 30px / 700, letter-spacing −0.01em | One per page. Exception: Hierarchies uses 28px. |
| Detail title (h2 inside a panel) | 28px / 700, line-height 1.25 | Selected item's name. Hierarchies node name 30px. |
| Section title (h3) | 16px / 700 | "Request details", "What changed" … sentence case. |
| Panel heading (h2 in a list panel) | 18px / 700 | "Needs your attention", "Recent activity" … |
| Group header in a list | 14px / 700 + count 13px `--nx-text-3` | On `--nx-surface-2` background. |
| Body | 14–15px / 400 | Row titles 15px / 600. |
| Field label | 13px / 600 `--nx-text-2`, sentence case | "Hierarchy", "From version" … Never ALL CAPS. |
| Meta line | 13px / 400 `--nx-text-2` or `--nx-text-3` | |
| Tiny caps label | 12px / 700, letter-spacing 0.08em, `--nx-text-3` | Only allowed on Home snapshot labels, Hierarchies "WHERE IT LIVES"/property category headers, dropdown group headers (PRIMARY / ALTERNATES, Finance/HR column groups). Nowhere else. |
| Big fact value | 18–20px / 700 | Facts rows (Sandboxes, Versions). |

Copy rules: sentence case; no exclamation marks; no "AI-style" helper sentences under titles. A line under a page title is allowed only when it states live state (e.g. "3 requests need your decision · 1 overdue"). Use `·` (middle dot with spaces) to join short facts.

### A3. Shape, spacing, elevation

| Element | Radius | Height | Border |
|---|---|---|---|
| Panel / card / table container | 8px | — | 1px `--nx-border` |
| Input, select, date, textarea, joined toggle group, square icon button | 4px | 36px (38px for page-level search) | 1px `--nx-control-border` |
| Button (filled or outline) | 999px (pill) | 38px default, 34px in bars, 32px in rows/cards | outline = 1px `--nx-control-border`, white bg |
| Small tag (status/ownership) | 4px | auto, padding 1px 8px, 13px/600 | 1px tint-border |
| Menu / popover | 6–8px | — | 1px `--nx-border` or `--nx-control-border`, shadow `0 8px 24px rgba(0,0,0,0.10)` |
| Count badge (draft) | 999px | 26px min-width | none |

- Page content column: `max-width: 1320px; margin: 0 auto; padding: 26px 24px 28px; gap: 20px` (vertical stack). Hierarchies uses `padding: 24px; gap: 18px`.
- Inside panels: horizontal padding 20px (lists) / 28px (detail areas); rows 14px vertical padding.
- No shadows on panels. Shadows only on popovers/menus, the sticky draft bar (`0 -2px 8px rgba(0,0,0,0.04)`), and toasts.
- Selected row pattern (used everywhere): `background: --nx-tint; box-shadow: inset 3px 0 0 --nx-brand;` unselected rows white.

### A4. Components (reuse exactly)

**A4.1 Primary button** — bg `--nx-brand`, text white 14px/600, pill, 38px, padding 0 20px, no border.
**A4.2 Secondary button** — white bg, 1px `--nx-control-border`, text `--nx-text` 14px/600, pill.
**A4.3 Danger text button** — transparent, no border, text `--nx-danger` 14px/600 (Reject, Discard sandbox, Withdraw).
**A4.4 Danger filled** — bg/border `--nx-danger`, white text (only the confirm step of Reject).
**A4.5 Text link** — `--nx-link`, underline, offset 2px, 13–14px.
**A4.6 Select** — `appearance: none`, 36px, 4px radius, padding `0 32px 0 10px`, 14px/600, chevron SVG 12px stroke `#5C5C5C` 2.4 absolutely positioned right 12px, `pointer-events: none`.
**A4.7 Joined toggle (segmented)** — container `display:inline-flex; border:1px solid --nx-control-border; border-radius:4px; overflow:hidden`. Segments 34px (30px in context bar, 28px small) tall, padding 0 14px, 14px/600; selected = `--nx-brand` bg + white text; unselected = white + `--nx-text`; every segment after the first has `border-left: 1px solid --nx-control-border`. `aria-pressed` on each.
**A4.8 Switch** — `role="switch" aria-checked`, track 34×20 radius 999, on `--nx-brand` / off `--nx-control-border`, knob 16×16 white, left 2px (off) / 16px (on), shadow `0 1px 2px rgba(0,0,0,.2)`; label text 14px to its right, gap 10px.
**A4.9 Tab row (in-panel)** — `role="tablist"`, row padding `0 12px`, gap 4px, bottom border 1px `--nx-border`. Tab: 46px tall (44px on Sandboxes), padding 0 10px, `border-bottom: 3px solid` (`--nx-brand` when selected, transparent otherwise), label 14px weight 700 selected / 500 not, colour `--nx-text` selected / `--nx-text-2` not; count after label 13px/400 `--nx-text-3` (red/700 when it represents blocking problems).
**A4.10 Master–detail split** — single panel (A3), internal grid `grid-template-columns: <list width> minmax(0,1fr)`, list column `border-right: 1px solid --nx-border`. List widths: Compare/Worklist 400px, Versions none (table), Sandboxes 340px, As-Was 400px (separate panels).
**A4.11 List row (button)** — full width, `display:flex; flex-direction:column; gap:3–4px; padding:14px 20px; border-bottom:1px solid --nx-divider; text-align:left`, title 15px/600, then 1–2 meta lines. Selected pattern from A3. `aria-current="true"` when selected.
**A4.12 Before/after table** — container A3; header row on `--nx-surface-2`, 13px/600 `--nx-text-2`, cell padding 10px 12–16px; body rows 14px, top border `--nx-divider` from the 2nd row; Before cell `--nx-text-3` + line-through (no strike when the before value is "—"/"New"/"Not in live"); After cell 600 on `--nx-tint`.
**A4.13 Timeline** — container `position:relative; padding-left:22px`; vertical line 2px `--nx-divider` at left 5px; each item: dot 12×12 circle, 2px white border, `box-shadow:0 0 0 1px <dot colour>`, placed at left −22px top 4–5px; text 14px/600 then meta 12px `--nx-text-3`. Dot colours: approved `--nx-brand`, comment `--nx-text-3`, other/system `--nx-muted-dot`.
**A4.14 Toast** — fixed, bottom 76px (24px on pages without draft bar), centred, bg `--nx-text`, white 14px, radius 4px, padding 10px 16px, auto-hide 2500ms, `role="status"`. Worklist toast adds an **Undo** button (30px, radius 4px, bg rgba(255,255,255,.14)).
**A4.15 Empty state** — centred in its area, title 18px/700, one line 14px `--nx-text-2`, padding 40–56px.
**A4.16 Status tag** — inline, 13px/600, 1px border, 4px radius, padding 1px 8px. Green variant: text `--nx-link`, border `--nx-tint-border`. Neutral: text `--nx-text-2`, border `--nx-control-border`. Red: text `--nx-danger`, border `--nx-danger-border`.

### A5. App shell (top of every page)

Root: `min-height:100vh; background:--nx-page; display:flex; flex-direction:column; font-family: A2`.

**A5.1 Header band** (`<header>`, bg `--nx-header-bg`, white text)
- Row 1: inner `max-width:1320px; margin:0 auto; padding:12px 24px 0; display:flex; align-items:center; gap:16px`:
  1. Logo placeholder: dashed 1.5px rgba(255,255,255,.7) box, radius 4px, padding 2px 8px, "LOGO" 12px/700 (replace with the real Fidelity logo asset).
  2. "Nexus" 24px/700.
  3. "Master Data Central" 13px rgba(255,255,255,.75).
  4. Flexible spacer.
  5. Help icon button 32×32 (question-mark-in-circle icon 20px, stroke 1.7) `aria-label="Help"`.
  6. Notifications icon button 32×32 (bell icon) with count bubble: absolute top 1px right 1px, min 15×15, radius 999, bg `--nx-notify`, text `#141414` 10px/700. `aria-label="Notifications, 3 new"`.
  7. Environment pill "Development": 12px, 1px rgba(255,255,255,.5) border, radius 999, padding 3px 12px.
  8. Vertical divider 1×22 rgba(255,255,255,.25).
  9. User button: avatar circle 30×30 rgba(255,255,255,.16) with initials 12px/700 ("VA"), then name 13px ("E2E Version Admin").
- Row 2 — main navigation `<nav aria-label="Main">`: `max-width:1320px; margin:0 auto; padding:4px 16px 0; height:42px; display:flex; gap:4px`. Each tab is an `<a>`: padding 0 12px, 14px, `border-bottom:3px solid` (`--nx-tint-border` when current, transparent otherwise), weight 700 current / 500 other, colour white current / rgba(255,255,255,.78) other, `aria-current="page"` on current.
  - Tab order: **Home · Hierarchies · Worklist [3] · Queries · Compare · As-Was · Sandboxes · Versions** (the Admin entry used in early boards is replaced by Sandboxes + Versions).
  - Worklist badge: 11px/700, text `--nx-header-bg`, bg `--nx-tint-border`, radius 999, padding 0 6px, line-height 16px. Shows the number of requests waiting for the user's decision; hidden when 0.

**A5.2 Context bar** (white, bottom border 1px `--nx-border`): inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:24px`.
1. Label "Version" 13px `--nx-text-2` + select (32px, 4px radius, 13px/600): options "2026-11 · Working", "2026-10 · Finalized". Changing it re-scopes every screen.
2. Label "Viewing as of" + date input (32px, 4px radius, 13px). Default today.
3. "Work in" + joined toggle (A4.7, 30px, 13px): **Live data** | **Sandbox**. Selected = `--nx-brand`.
4. Spacer, then link "Manage versions" (13px, `--nx-link`) → Versions screen.

**A5.3 Sticky draft bar** (all screens except Sandboxes): `position:sticky; bottom:0; background:#FFF; border-top:1px solid --nx-border; box-shadow:0 -2px 8px rgba(0,0,0,.04); z-index:20`. Inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:14px; font-size:14px`.
1. Count badge 26px pill: with drafts bg `--nx-tint-3` text `--nx-link`; empty bg `--nx-divider-soft` text `--nx-text-2`. 13px/700.
2. Text: **"Changes in your draft"** (700; singular "Change in your draft"; empty "No changes in your draft") + ` · nothing changes until approved` (`--nx-text-2`; empty: "· edits you make are collected here").
3. Spacer.
4. Link-style button "View changes" / "Hide changes" toggles a popover (`aria-expanded`).
5. Secondary 34px "Discard".
6. Primary 34px "Review and submit".
- When empty, Discard and Review and submit get `aria-disabled="true"` and `opacity:.5` (do not use the boolean `disabled` attribute binding).
- Popover: absolute, bottom calc(100% + 8px), left 24px, width 480px, radius 8px, shadow A3, padding 8px 0. Header "Changes in your draft" 13px/600 `--nx-text-2` padding 6px 16px. Each item row min-height 42px, top divider, text button 14px (clicking navigates to the node), remove × icon button 30×30 `aria-label="Remove from draft"`. Empty: "Your draft is empty." 14px `--nx-text-2`.
- Example items: "Move 34307 · AGQNT → AGCOE in ORGTL", "Edit 34301 · name “QNT Analytics Platform”".

### A6. Accessibility & behaviour baseline
- Every input has a `<label>` (visually hidden class when the design shows none: `position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)`).
- Tabs use `role="tablist"/"tab"` + `aria-selected`; segmented toggles use `aria-pressed`; switches `role="switch"` + `aria-checked`; list selection `aria-current`.
- Decorative icons/dots `aria-hidden="true"`; meaning is always also in text.
- Disabled-looking actions use `aria-disabled` + reduced opacity + a visible reason somewhere nearby.
- Text never truncates with ellipsis in lists/detail; long names wrap (`overflow-wrap:anywhere` on names/paths).
- All numbers use `en-US` grouping (2,818). Dates: "18 Nov 2026"; times 24h "10:30".

### A7. Shared demo data (use the same values on every screen)
- User: E2E Version Admin (`e2e_vadmin`, initials VA). Other people: u_editor1, u_approver1, u_admin, E2E Steward.
- Versions: **2026-11** Working (business date 18 Nov 2026, created from 2026-10), **E2E working** Working (15 Nov 2026), **2026-10** Finalized (28 Oct 2026, frozen 18 Nov 2026 06:22).
- Hierarchies: ORGTL "Total Fidelity" Primary 2,818 nodes 14 levels; ORGTP "Total Fidelity Technology" Alternate 516/12; AMBUS "Asset Management BU Alternate" Alternate 1,501/12; plus 12 alternates: E2E_H E2E Legal Group 142/8, E2E_MGMT E2E Management View 96/7, FINRPT Finance Reporting 1,210/10, LEGENT Legal Entities 388/6, GEOREG Geographic Regions 240/5, CCOWN Cost Centre Owners 2,236/9, HRORG HR Organisation 1,890/11, TAXREP Tax Reporting 610/8, OPSDEL Operations Delivery 744/9, PRODLN Product Lines 455/7, RISKV Risk View 302/6, PROJTL Project Portfolio 128/5 (15 total).
- Key nodes: ORGTL › OC005 Asset Management › AM Asset Management Executive › AMT Asset Management Technology › AMQNT Quant Technology › {AGCOE AM AI Center of Excellence, AGQNT US Quant Technology}. Leaves under AGQNT: 31679 UK QNT Tech, 34295 QNT Engineering, 34299 QNT Leadership, 34301 QNT Analytics Platform, 34322 QNT Contingent (Inactive). 34307 QNT Quant Dev (under AGCOE in ORGTL; under AGQNT in ORGTP/AMBUS).
- Draft (pending, not submitted): Move 34307 AGQNT → AGCOE in ORGTL; Rename 34301 → "QNT Analytics Platform".
- Integrity rules: CODE_UNIQUE, PARENT_EXISTS, PARENT_IS_LIMB, NO_CYCLES.


---

## Part B — As-Was screen

### B1. Page structure
```
[A5.1 Header] [A5.2 Context bar]
┌ content column (max 1320, padding 26 24 28, gap 20) ─────────────────────────────┐
│ B2 Title row: As-Was / "Showing ORGTL as it was on 13 Nov 2026 at 10:30"  [Compare with now] │
│ B3 Moment panel                                                                   │
│    Hierarchy [▾]   Date and time [datetime][Now]                                  │
│    ─────────────────────────────────────────────                                  │
│    [<] November 2026 [>]  18 changes this month                                   │
│    day strip: 30 columns, bar height = number of changes                          │
│ ┌ B4 Day's changes (400px) ┐  ┌ B5 Tree at this moment ─────────────────────┐  │
│ │ Friday, 13 Nov · 4 changes│  │ ORGTL at 10:30, 13 Nov 2026  Read only  (●) Show later changes │
│ │ ● The tree on the right…  │  │ "4 changes made after this time are marked…" │  │
│ │ 10:31 QNT Research …      │  │ tree rows with tags                          │  │
│ └───────────────────────────┘  └──────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────────────┘
[A5.3 Draft bar]
```

### B2. Title row
`display:flex; align-items:flex-end; gap:12px 16px; flex-wrap:wrap`.
- Left (flex 1, gap 6): h1 30px "As-Was"; state line 15px `--nx-text-2`:
  - past moment: "Showing <H> as it was on <D Mon YYYY> at <HH:MM>" (time "start of day" when 00:00), e.g. "Showing ORGTL as it was on 13 Nov 2026 at 10:30"
  - now: "Showing <H> as it is now".
- Right: secondary pill 38px link "Compare with now" → Compare (From = version at the chosen moment, To = current working version).

### B3. Moment panel
`<section aria-label="Choose a moment">`, panel.

**B3.1 Controls** `display:flex; flex-wrap:wrap; align-items:flex-end; gap:16px 28px; padding:18px 20px`:
1. **Hierarchy** (label 13px/600 `--nx-text-2`) — select 300px: ORGTL · Total Fidelity / ORGTP · Total Fidelity Technology / AMBUS · Asset Management BU Alternate.
2. **Date and time** — row gap 8:
   - `datetime-local` input 36px, 4px radius, 14px/600, `min="2026-10-01T00:00"`, `max=<now>`. Values after now are clamped to now.
   - "Now" button 36px, **4px radius** (it belongs to the input), 1px border, 14px/600, `aria-pressed`: when viewing now → bg/border `--nx-brand`, white text; otherwise white, `--nx-control-border`, `--nx-text`.

**B3.2 Day strip** `border-top:1px solid --nx-divider; padding:14px 20px 16px; column; gap:10px`.
- Month row (`align-items:center; gap:8px`):
  - Previous-month button 30×30, radius 4, 1px border, chevron-left 14px `--nx-text-2`, `aria-label="Previous month"`; at the first available month `aria-disabled="true"` + opacity .35.
  - h2 15px/700, min-width 130px, centred: "November 2026".
  - Next-month button, same pattern.
  - 13px `--nx-text-3`, margin-left 6px: "18 changes this month" / "1 change this month" / "No changes this month".
- Days grid `display:grid; grid-template-columns:repeat(<days in month>, minmax(0,1fr)); gap:2px`. Each day is a button (`aria-pressed`, `aria-label="13 Nov · 4 changes"` or "· future"), height 74px, `flex-direction:column; align-items:center; justify-content:flex-end; gap:6px; padding:6px 0; radius 4px`:
  - bar 8px wide, radius 2px, height = `10 + n×9` px when n>0 changes, 3px when 0.
  - bar colour: selected day with changes `--nx-brand`; other days with changes `--nx-tint-border` (#A8CF9C); no changes `--nx-border`; future `--nx-divider-soft`.
  - day number 13px: selected or today 700 else 500; colour selected `--nx-link`, future `--nx-muted-dot`, else `--nx-text-2`.
  - selected cell background `--nx-tint` + `box-shadow: inset 0 0 0 1px --nx-tint-border`.
  - future days `aria-disabled="true"`, cursor default, not clickable.
  - Click: sets the moment to that day 00:00 (today → now).

### B4. Changes on this day (left panel)
Grid under B3: `display:grid; grid-template-columns:400px minmax(0,1fr); gap:20px; align-items:start`.

Panel `<section aria-label="Changes on this day">`, overflow hidden.
- Header `padding:16px 20px 12px; align-items:baseline; gap:10px`: h2 18px/700 "Friday, 13 Nov" (weekday, D Mon) + 13px `--nx-text-3` "4 changes" / "1 change" / "No changes".
- Empty: row padding 20, top divider, 14px `--nx-text-2` "No changes on this day."
- Event row (button, `aria-current` when its time equals the moment): `display:grid; grid-template-columns:48px minmax(0,1fr); gap:12px; padding:14px 20px; border-top:1px solid --nx-divider`; selected = A3 pattern.
  - time 14px/600 `--nx-text-2` "10:42"
  - text column gap 3: node name 15px/600 (new name for renames) / what happened 14px `--nx-text` / 13px `--nx-text-3` "<code> · <who> · <request>".
  - Click: moves the moment to exactly that event's time (tree shows the state right after it).
- **Moment marker row** inserted between events, before the first event later than the moment (or at the end if none are later): `role="separator"`, `padding:8px 20px; top divider; bg --nx-surface-2; gap 10px`: 8×8 dot `--nx-brand` + 13px/600 `--nx-link` "The tree on the right is at 10:30" (or "…is current" when viewing now; "…is at start of day" for 00:00).
- What-happened sentences: "Added under <parent>", "Removed from <parent>", "Moved from <A> to <B>", "Renamed from “<old>”", "Made inactive|active", "<Property> changed from <a> to <b>".

### B5. Tree at this moment (right panel)
Panel `<section aria-label="Tree at this moment">`, overflow hidden.

**B5.1 Header** `padding:16px 20px 14px; column; gap:4px; border-bottom:1px solid --nx-divider`:
- Row (`align-items:center; gap:12px; wrap`): h2 18px/700 "ORGTL at 10:30, 13 Nov 2026" (now: "ORGTL today") · 13px `--nx-text-3` "Read only" · spacer · switch (A4.8, 32px row) "Show later changes" (default on).
- Line 14px `--nx-text-2`:
  - nothing after: "No changes since. This matches the tree today."
  - later changes, switch on: "<n> changes made after this time are marked with dashed tags."
  - later changes, switch off: "<n> changes made after this time are hidden."

**B5.2 Tree rows** `padding:8px 0 12px`. Rendered: ancestors of the working area (ORGTL › OC005 › AM › AMT › AMQNT) then the full subtree under AMQNT as it stood at the moment. Row: `display:flex; align-items:center; gap:8px; min-height:36px; padding:2px 20px 2px <20 + depth×22>px; flex-wrap:wrap`.
1. 14px icon slot: limb → chevron-down 12px `--nx-text-3`; leaf → 5×5 dot `--nx-muted-dot`.
2. code 13px `--nx-text-3`.
3. name 14px (600 for depth 0 and the just-changed node, else 500) `--nx-text`; inactive nodes `--nx-text-3` with suffix " · Inactive" (400, `--nx-text-3`).
4. tags (0–2), each 12px/600, radius 4, padding 1px 8px, nowrap:
   - **Just-applied tag** (event at exactly the moment): solid 1px `--nx-tint-border`, text `--nx-link`: "Added · 10:31", "Moved in · 10:42", "Renamed · 10:48", "Now inactive · 10:52", "GL 0444 · 14:20". The node row also gets the selected pattern (`--nx-tint` + 3px `--nx-brand` edge).
   - **Later tag** (switch on, next later event for that node): dashed 1px `--nx-control-border`, text `--nx-text-2`: "Added 13 Nov", "Removed 12 Nov", "Moves to AGCOE · 13 Nov", "Renamed 13 Nov", "Inactive from 13 Nov", "GL changes 9 Nov".
- **Ghost rows** (code and name struck through, colour `--nx-text-3`):
  - a node removed exactly at the moment is shown where it was, with its just-applied "Removed · HH:MM" tag
  - with the switch on, nodes added later are shown under their future parent with a dashed "Added <date>" tag.

### B6. Demo data (approved events, Nov 2026)

| When | Type | Node | Detail | Hier | By | Request |
|---|---|---|---|---|---|---|
| 4 Nov 11:20 | Property | 34299 QNT Leadership | Oracle GL company 0512 → 0610 | all | E2E Steward | CR-1033 |
| 9 Nov 14:20 | Property | 34295 QNT Engineering | Oracle GL company 0512 → 0444 | all | E2E Steward | CR-1035 |
| 12 Nov 16:05 | Removed | 34322 QNT Contingent | from AGQNT | ORGTL | E2E Steward | CR-1036 |
| 13 Nov 10:31 | Added | 99301 QNT Research | under AGQNT | ORGTL | u_editor1 | CR-1038 |
| 13 Nov 10:42 | Moved | 34307 QNT Quant Dev | AGQNT → AGCOE | ORGTL | u_editor1 | CR-1038 |
| 13 Nov 10:48 | Renamed | 34301 | “QNT Analytics” → “QNT Analytics Platform” | all | u_editor1 | CR-1038 |
| 13 Nov 10:52 | Status | 34301 | Active → Inactive | all | u_editor1 | CR-1038 |
| 17 Nov 15:30 | Added | 99302 AI Platform Ops | under AGCOE | ORGTL | u_editor1 | CR-1047 |

- Default moment: 13 Nov 2026 10:30. Now = 18 Nov 2026 06:22. Months available: October 2026, November 2026.
- Starting tree (before any event): AMQNT › AGCOE (empty), AGQNT › 31679, 34295, 34299, 34301 "QNT Analytics", 34307, 34322 (Inactive).

### B7. Behaviour
- Only approved/committed changes appear (no drafts, no sandboxes). The tree is read only; there are no edit actions on this screen.
- Changing hierarchy keeps the moment; events not in that hierarchy are filtered out (global events such as renames/property changes show in every hierarchy).
- URL holds `h` and `t`.

### B8. Acceptance checklist
- [ ] Labels: "Hierarchy", "Date and time" (sentence case).
- [ ] Day strip bars scale with change count; selected day green; future disabled.
- [ ] Event rows: time, name, plain-language action, code · who · request; no type colours or caps labels.
- [ ] Moment marker row reads "The tree on the right is at HH:MM".
- [ ] Solid green tag for the change at the moment, dashed grey tags for later changes, struck-through ghost rows.
