# Nexus – Versions screen · UI specification

**Route:** `/versions?status=<All|Working|Submitted|Finalized|Expired>` · **Header tab:** Versions (also opened by "Manage versions" in the context bar) · **Mockup board:** "Versions (new)" — `Versions.dc.html`
**Purpose:** see all versions, which one you are working in, and take the one next step each version allows. Deliberately a single compact table with no explanatory text.

Backend reminder (do not show as text): working versions share one bitemporal store; a committed change appears in every working version whose business date is on or after the change's effective date. Finalized versions are frozen (business date + recorded time) and never change.


---

## Part A — Shared foundations (identical on every Nexus screen)

> This part is the same in all 8 screen specs. Do not change any value here for one screen only. If a value here conflicts with something in Part B, Part A wins unless Part B says it overrides it.

### A1. Design tokens

Use these exact values. Do not add new colours, shades, shadows or radii.

| Token | Value | Use |
|---|---|---|
| `--nx-header-bg` | `#044014` | Top header band only. Never used for buttons or highlights in the page body. |
| `--nx-brand` | `#368727` | Every filled primary button, active tab underline in the page body, selected toggle segment, switch "on", checkbox fill, selected day bar, timeline dot "approved", selected-row left edge. White text on it (contrast 4.5:1). |
| `--nx-link` | `#2B6A1F` | All text links (underlined, `text-underline-offset: 2px`), green tag text, positive status text. |
| `--nx-link-hover` | `#1E4F15` | Link hover. |
| `--nx-tint` | `#F3F6F1` | Selected row background, "new value" cell background, current-step background. |
| `--nx-tint-2` | `#E6EFE2` | Selected option background in dropdown lists, hierarchy icon tile. |
| `--nx-tint-3` | `#E8F1E5` | Draft-count badge background; sandbox strip background. |
| `--nx-tint-border` | `#A8CF9C` | Border of green outlined tags; header active-tab underline; header badge background. |
| `--nx-tint-border-2` | `#DCE6D8` / `#C5D9BE` | Border of pale-green boxes (draft callout, sandbox strip). |
| `--nx-page` | `#F9F7F5` | Page background under everything below the header. |
| `--nx-surface` | `#FFFFFF` | Panels, inputs, menus. |
| `--nx-surface-2` | `#FCFBFA` | Table header rows, group header rows, inset boxes, separator rows. |
| `--nx-border` | `#E5E1DC` | Panel borders, table borders, tab-row bottom border. |
| `--nx-divider` | `#EEEAE5` | Row dividers inside panels, section dividers. |
| `--nx-divider-soft` | `#F1EEEA` | Very light row dividers (property rows), neutral chip background. |
| `--nx-control-border` | `#C9C4BE` | Input/select/outline-button borders, unselected switch track. |
| `--nx-text` | `#141414` | Primary text. |
| `--nx-text-2` | `#5C5C5C` | Secondary text, field labels, meta lines. |
| `--nx-text-3` | `#8A8580` | Tertiary text: codes under names, counts in tabs, timestamps, placeholders for empty values. |
| `--nx-muted-dot` | `#B5AFA8` | Neutral timeline dots, leaf dots. |
| `--nx-danger` | `#B42318` | Only: overdue, errors, conflicts, Reject / Delete / Discard-sandbox actions. Never decorative. |
| `--nx-danger-border` | `#E8B4AE` | Border of a red outlined tag / blocked card. |
| `--nx-notify` | `#F2B33D` | Only the notification-count bubble in the header. |

**Colour rules (hard):**
1. One accent: green. No blue, purple or amber anywhere in the page body.
2. A change type (added, moved, renamed …) is shown with **words**, never a colour per type.
3. Red appears only when something is wrong or destructive.
4. Old value = `--nx-text-3` + `line-through`. New value = `font-weight: 600` on `--nx-tint`.

### A2. Typography

- Font stack: `'Fidelity Sans', 'Hind', Helvetica, Arial, sans-serif`. Load Hind 400/500/600/700 from Google Fonts as the fallback; if the app already ships Fidelity Sans (as the Fidelity Shares app does), use it.
- No monospace font anywhere (codes use the normal font).
- Base text colour `--nx-text`.

| Role | Size / weight | Notes |
|---|---|---|
| Page title (h1) | 30px / 700, letter-spacing −0.01em | One per page. Exception: Hierarchies uses 28px. |
| Detail title (h2 inside a panel) | 28px / 700, line-height 1.25 | Selected item's name. Hierarchies node name 30px. |
| Section title (h3) | 16px / 700 | "Request details", "What changed" … sentence case. |
| Panel heading (h2 in a list panel) | 18px / 700 | "Needs your attention", "Recent activity" … |
| Group header in a list | 14px / 700 + count 13px `--nx-text-3` | On `--nx-surface-2` background. |
| Body | 14–15px / 400 | Row titles 15px / 600. |
| Field label | 13px / 600 `--nx-text-2`, sentence case | "Hierarchy", "From version" … Never ALL CAPS. |
| Meta line | 13px / 400 `--nx-text-2` or `--nx-text-3` | |
| Tiny caps label | 12px / 700, letter-spacing 0.08em, `--nx-text-3` | Only allowed on Home snapshot labels, Hierarchies "WHERE IT LIVES"/property category headers, dropdown group headers (PRIMARY / ALTERNATES, Finance/HR column groups). Nowhere else. |
| Big fact value | 18–20px / 700 | Facts rows (Sandboxes, Versions). |

Copy rules: sentence case; no exclamation marks; no "AI-style" helper sentences under titles. A line under a page title is allowed only when it states live state (e.g. "3 requests need your decision · 1 overdue"). Use `·` (middle dot with spaces) to join short facts.

### A3. Shape, spacing, elevation

| Element | Radius | Height | Border |
|---|---|---|---|
| Panel / card / table container | 8px | — | 1px `--nx-border` |
| Input, select, date, textarea, joined toggle group, square icon button | 4px | 36px (38px for page-level search) | 1px `--nx-control-border` |
| Button (filled or outline) | 999px (pill) | 38px default, 34px in bars, 32px in rows/cards | outline = 1px `--nx-control-border`, white bg |
| Small tag (status/ownership) | 4px | auto, padding 1px 8px, 13px/600 | 1px tint-border |
| Menu / popover | 6–8px | — | 1px `--nx-border` or `--nx-control-border`, shadow `0 8px 24px rgba(0,0,0,0.10)` |
| Count badge (draft) | 999px | 26px min-width | none |

- Page content column: `max-width: 1320px; margin: 0 auto; padding: 26px 24px 28px; gap: 20px` (vertical stack). Hierarchies uses `padding: 24px; gap: 18px`.
- Inside panels: horizontal padding 20px (lists) / 28px (detail areas); rows 14px vertical padding.
- No shadows on panels. Shadows only on popovers/menus, the sticky draft bar (`0 -2px 8px rgba(0,0,0,0.04)`), and toasts.
- Selected row pattern (used everywhere): `background: --nx-tint; box-shadow: inset 3px 0 0 --nx-brand;` unselected rows white.

### A4. Components (reuse exactly)

**A4.1 Primary button** — bg `--nx-brand`, text white 14px/600, pill, 38px, padding 0 20px, no border.
**A4.2 Secondary button** — white bg, 1px `--nx-control-border`, text `--nx-text` 14px/600, pill.
**A4.3 Danger text button** — transparent, no border, text `--nx-danger` 14px/600 (Reject, Discard sandbox, Withdraw).
**A4.4 Danger filled** — bg/border `--nx-danger`, white text (only the confirm step of Reject).
**A4.5 Text link** — `--nx-link`, underline, offset 2px, 13–14px.
**A4.6 Select** — `appearance: none`, 36px, 4px radius, padding `0 32px 0 10px`, 14px/600, chevron SVG 12px stroke `#5C5C5C` 2.4 absolutely positioned right 12px, `pointer-events: none`.
**A4.7 Joined toggle (segmented)** — container `display:inline-flex; border:1px solid --nx-control-border; border-radius:4px; overflow:hidden`. Segments 34px (30px in context bar, 28px small) tall, padding 0 14px, 14px/600; selected = `--nx-brand` bg + white text; unselected = white + `--nx-text`; every segment after the first has `border-left: 1px solid --nx-control-border`. `aria-pressed` on each.
**A4.8 Switch** — `role="switch" aria-checked`, track 34×20 radius 999, on `--nx-brand` / off `--nx-control-border`, knob 16×16 white, left 2px (off) / 16px (on), shadow `0 1px 2px rgba(0,0,0,.2)`; label text 14px to its right, gap 10px.
**A4.9 Tab row (in-panel)** — `role="tablist"`, row padding `0 12px`, gap 4px, bottom border 1px `--nx-border`. Tab: 46px tall (44px on Sandboxes), padding 0 10px, `border-bottom: 3px solid` (`--nx-brand` when selected, transparent otherwise), label 14px weight 700 selected / 500 not, colour `--nx-text` selected / `--nx-text-2` not; count after label 13px/400 `--nx-text-3` (red/700 when it represents blocking problems).
**A4.10 Master–detail split** — single panel (A3), internal grid `grid-template-columns: <list width> minmax(0,1fr)`, list column `border-right: 1px solid --nx-border`. List widths: Compare/Worklist 400px, Versions none (table), Sandboxes 340px, As-Was 400px (separate panels).
**A4.11 List row (button)** — full width, `display:flex; flex-direction:column; gap:3–4px; padding:14px 20px; border-bottom:1px solid --nx-divider; text-align:left`, title 15px/600, then 1–2 meta lines. Selected pattern from A3. `aria-current="true"` when selected.
**A4.12 Before/after table** — container A3; header row on `--nx-surface-2`, 13px/600 `--nx-text-2`, cell padding 10px 12–16px; body rows 14px, top border `--nx-divider` from the 2nd row; Before cell `--nx-text-3` + line-through (no strike when the before value is "—"/"New"/"Not in live"); After cell 600 on `--nx-tint`.
**A4.13 Timeline** — container `position:relative; padding-left:22px`; vertical line 2px `--nx-divider` at left 5px; each item: dot 12×12 circle, 2px white border, `box-shadow:0 0 0 1px <dot colour>`, placed at left −22px top 4–5px; text 14px/600 then meta 12px `--nx-text-3`. Dot colours: approved `--nx-brand`, comment `--nx-text-3`, other/system `--nx-muted-dot`.
**A4.14 Toast** — fixed, bottom 76px (24px on pages without draft bar), centred, bg `--nx-text`, white 14px, radius 4px, padding 10px 16px, auto-hide 2500ms, `role="status"`. Worklist toast adds an **Undo** button (30px, radius 4px, bg rgba(255,255,255,.14)).
**A4.15 Empty state** — centred in its area, title 18px/700, one line 14px `--nx-text-2`, padding 40–56px.
**A4.16 Status tag** — inline, 13px/600, 1px border, 4px radius, padding 1px 8px. Green variant: text `--nx-link`, border `--nx-tint-border`. Neutral: text `--nx-text-2`, border `--nx-control-border`. Red: text `--nx-danger`, border `--nx-danger-border`.

### A5. App shell (top of every page)

Root: `min-height:100vh; background:--nx-page; display:flex; flex-direction:column; font-family: A2`.

**A5.1 Header band** (`<header>`, bg `--nx-header-bg`, white text)
- Row 1: inner `max-width:1320px; margin:0 auto; padding:12px 24px 0; display:flex; align-items:center; gap:16px`:
  1. Logo placeholder: dashed 1.5px rgba(255,255,255,.7) box, radius 4px, padding 2px 8px, "LOGO" 12px/700 (replace with the real Fidelity logo asset).
  2. "Nexus" 24px/700.
  3. "Master Data Central" 13px rgba(255,255,255,.75).
  4. Flexible spacer.
  5. Help icon button 32×32 (question-mark-in-circle icon 20px, stroke 1.7) `aria-label="Help"`.
  6. Notifications icon button 32×32 (bell icon) with count bubble: absolute top 1px right 1px, min 15×15, radius 999, bg `--nx-notify`, text `#141414` 10px/700. `aria-label="Notifications, 3 new"`.
  7. Environment pill "Development": 12px, 1px rgba(255,255,255,.5) border, radius 999, padding 3px 12px.
  8. Vertical divider 1×22 rgba(255,255,255,.25).
  9. User button: avatar circle 30×30 rgba(255,255,255,.16) with initials 12px/700 ("VA"), then name 13px ("E2E Version Admin").
- Row 2 — main navigation `<nav aria-label="Main">`: `max-width:1320px; margin:0 auto; padding:4px 16px 0; height:42px; display:flex; gap:4px`. Each tab is an `<a>`: padding 0 12px, 14px, `border-bottom:3px solid` (`--nx-tint-border` when current, transparent otherwise), weight 700 current / 500 other, colour white current / rgba(255,255,255,.78) other, `aria-current="page"` on current.
  - Tab order: **Home · Hierarchies · Worklist [3] · Queries · Compare · As-Was · Sandboxes · Versions** (the Admin entry used in early boards is replaced by Sandboxes + Versions).
  - Worklist badge: 11px/700, text `--nx-header-bg`, bg `--nx-tint-border`, radius 999, padding 0 6px, line-height 16px. Shows the number of requests waiting for the user's decision; hidden when 0.

**A5.2 Context bar** (white, bottom border 1px `--nx-border`): inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:24px`.
1. Label "Version" 13px `--nx-text-2` + select (32px, 4px radius, 13px/600): options "2026-11 · Working", "2026-10 · Finalized". Changing it re-scopes every screen.
2. Label "Viewing as of" + date input (32px, 4px radius, 13px). Default today.
3. "Work in" + joined toggle (A4.7, 30px, 13px): **Live data** | **Sandbox**. Selected = `--nx-brand`.
4. Spacer, then link "Manage versions" (13px, `--nx-link`) → Versions screen.

**A5.3 Sticky draft bar** (all screens except Sandboxes): `position:sticky; bottom:0; background:#FFF; border-top:1px solid --nx-border; box-shadow:0 -2px 8px rgba(0,0,0,.04); z-index:20`. Inner `max-width:1320px; padding:10px 24px; display:flex; align-items:center; gap:14px; font-size:14px`.
1. Count badge 26px pill: with drafts bg `--nx-tint-3` text `--nx-link`; empty bg `--nx-divider-soft` text `--nx-text-2`. 13px/700.
2. Text: **"Changes in your draft"** (700; singular "Change in your draft"; empty "No changes in your draft") + ` · nothing changes until approved` (`--nx-text-2`; empty: "· edits you make are collected here").
3. Spacer.
4. Link-style button "View changes" / "Hide changes" toggles a popover (`aria-expanded`).
5. Secondary 34px "Discard".
6. Primary 34px "Review and submit".
- When empty, Discard and Review and submit get `aria-disabled="true"` and `opacity:.5` (do not use the boolean `disabled` attribute binding).
- Popover: absolute, bottom calc(100% + 8px), left 24px, width 480px, radius 8px, shadow A3, padding 8px 0. Header "Changes in your draft" 13px/600 `--nx-text-2` padding 6px 16px. Each item row min-height 42px, top divider, text button 14px (clicking navigates to the node), remove × icon button 30×30 `aria-label="Remove from draft"`. Empty: "Your draft is empty." 14px `--nx-text-2`.
- Example items: "Move 34307 · AGQNT → AGCOE in ORGTL", "Edit 34301 · name “QNT Analytics Platform”".

### A6. Accessibility & behaviour baseline
- Every input has a `<label>` (visually hidden class when the design shows none: `position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)`).
- Tabs use `role="tablist"/"tab"` + `aria-selected`; segmented toggles use `aria-pressed`; switches `role="switch"` + `aria-checked`; list selection `aria-current`.
- Decorative icons/dots `aria-hidden="true"`; meaning is always also in text.
- Disabled-looking actions use `aria-disabled` + reduced opacity + a visible reason somewhere nearby.
- Text never truncates with ellipsis in lists/detail; long names wrap (`overflow-wrap:anywhere` on names/paths).
- All numbers use `en-US` grouping (2,818). Dates: "18 Nov 2026"; times 24h "10:30".

### A7. Shared demo data (use the same values on every screen)
- User: E2E Version Admin (`e2e_vadmin`, initials VA). Other people: u_editor1, u_approver1, u_admin, E2E Steward.
- Versions: **2026-11** Working (business date 18 Nov 2026, created from 2026-10), **E2E working** Working (15 Nov 2026), **2026-10** Finalized (28 Oct 2026, frozen 18 Nov 2026 06:22).
- Hierarchies: ORGTL "Total Fidelity" Primary 2,818 nodes 14 levels; ORGTP "Total Fidelity Technology" Alternate 516/12; AMBUS "Asset Management BU Alternate" Alternate 1,501/12; plus 12 alternates: E2E_H E2E Legal Group 142/8, E2E_MGMT E2E Management View 96/7, FINRPT Finance Reporting 1,210/10, LEGENT Legal Entities 388/6, GEOREG Geographic Regions 240/5, CCOWN Cost Centre Owners 2,236/9, HRORG HR Organisation 1,890/11, TAXREP Tax Reporting 610/8, OPSDEL Operations Delivery 744/9, PRODLN Product Lines 455/7, RISKV Risk View 302/6, PROJTL Project Portfolio 128/5 (15 total).
- Key nodes: ORGTL › OC005 Asset Management › AM Asset Management Executive › AMT Asset Management Technology › AMQNT Quant Technology › {AGCOE AM AI Center of Excellence, AGQNT US Quant Technology}. Leaves under AGQNT: 31679 UK QNT Tech, 34295 QNT Engineering, 34299 QNT Leadership, 34301 QNT Analytics Platform, 34322 QNT Contingent (Inactive). 34307 QNT Quant Dev (under AGCOE in ORGTL; under AGQNT in ORGTP/AMBUS).
- Draft (pending, not submitted): Move 34307 AGQNT → AGCOE in ORGTL; Rename 34301 → "QNT Analytics Platform".
- Integrity rules: CODE_UNIQUE, PARENT_EXISTS, PARENT_IS_LIMB, NO_CYCLES.


---

## Part B — Versions screen

### B1. Page structure
```
[A5.1 Header] [A5.2 Context bar]
┌ content column (max 1320, padding 26 24 28, gap 20) ─────────────────────────┐
│ B2  Versions ....................................................... [New version] │
│ B3  Panel                                                                     │
│     tabs: All 3 · Working 2 · Submitted 0 · Finalized 1 · Expired 0           │
│     header: Version | Business date | Status | Frozen | Created from | (actions) │
│     rows                                                                      │
└───────────────────────────────────────────────────────────────────────────────┘
[A5.3 Draft bar]
```

### B2. Title row
`display:flex; align-items:center; gap:16px`: h1 30px "Versions" (flex 1); primary 38px "New version" → opens a small dialog to choose the Finalized version to start from (toast in mockup: "Choose a finalized version to start from"). No sub line.

### B3. Versions panel
`<section aria-label="Versions">`, panel, overflow hidden.

**B3.1 Tabs** (A4.9) `aria-label="Filter by status"`: "All", "Working", "Submitted", "Finalized", "Expired", each with a count (count 0 still shown).

**B3.2 Table** — implemented as CSS grid rows with identical columns:
`grid-template-columns: minmax(0,2.2fr) 140px 120px 190px 120px 260px`.
- Header row: bg `--nx-surface-2`, bottom border `--nx-border`, 13px/600 `--nx-text-2`. Cells: "Version" (padding 10px 20px), "Business date", "Status", "Frozen", "Created from" (padding 10px 12px), last cell blank.
- Body row: `align-items:center; 14px; top border --nx-divider from the 2nd row`. The **current** version row (the one selected in the context bar) uses the selected pattern (`--nx-tint` + `inset 3px 0 0 --nx-brand`); others white.
  1. Version cell (padding 14px 20px; column gap 2):
     - line 1 (`align-items:center; gap:8px`): name 15px/700 + (current only) tag "Current" — 12px/600 `--nx-link`, 1px `--nx-tint-border`, radius 4, padding 0 6px.
     - line 2: short note 13px `--nx-text-3`.
  2. Business date (padding 14px 12px), e.g. "18 Nov 2026".
  3. Status 600: Working `--nx-link`; Submitted / Finalized `--nx-text`; Expired `--nx-text-3`.
  4. Frozen: date-time ("18 Nov 2026, 06:22") or "—" in `--nx-text-3`.
  5. Created from `--nx-text-2`: version code, "DRM export" or "—".
  6. Actions (padding 10px 20px 10px 12px; `display:flex; justify-content:flex-end; align-items:center; gap:14px`):
     - link "Open" (14px, underlined `--nx-link`) → Hierarchies at that version
     - link "Compare" → Compare with From = previous version, To = this one
     - one optional secondary 32px pill (13px/600) — the single next step for that row:

| Row condition | Button | Result |
|---|---|---|
| The current month-end working version (2026-11) | "Submit" | Status → Submitted; toast "2026-11 submitted for finalization" |
| Any other Working version | "Switch to" | Context-bar version changes to it; it becomes "Current"; toast "Now working in <name>" |
| Finalized | "Copy to new" | Creates a new Working version starting as an exact copy; toast "New working version created from <name>" |
| Submitted (admin) | "Finalize" (version admins only) | Status → Finalized, Frozen = now |
| Expired | none | — |

- Empty filter: one row 14px `--nx-text-2` padding 20 "No <status> versions." (e.g. "No expired versions.").

### B4. Demo data

| Version | Note | Business date | Status | Frozen | Created from | Button |
|---|---|---|---|---|---|---|
| **2026-11** (Current) | November month-end · open until 30 Nov | 18 Nov 2026 | Working | — | 2026-10 | Submit |
| E2E working | Testing only | 15 Nov 2026 | Working | — | — | Switch to |
| 2026-10 | October month-end baseline | 28 Oct 2026 | Finalized | 18 Nov 2026, 06:22 | DRM export | Copy to new |

Sort: Working first (newest business date first), then Submitted, Finalized (newest first), Expired.

### B5. Toasts
A4.14 (bottom 76px): see table in B3.2.

### B6. Permissions
- Everyone: view, Open, Compare, Switch to.
- Version admin: New version, Submit, Finalize, Copy to new. Non-admins don't see those buttons (the row keeps Open/Compare).

### B7. What NOT to build
No lifecycle diagrams, no explanatory paragraphs, no detail side panel, no "Open picture" wording (use "Open"), no status pills with icons.

### B8. Acceptance checklist
- [ ] Title row = "Versions" + New version only.
- [ ] One table; current version highlighted and tagged "Current".
- [ ] Open and Compare as links; at most one button per row.
- [ ] Frozen "—" for unfrozen versions.
